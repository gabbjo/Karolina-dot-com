# Karolina Bengtsson

Personal site. Plain HTML, CSS and JavaScript. No build step.

## Open it

From this folder:

```
python3 -m http.server
```

Then open http://localhost:8000

Opening the HTML file directly also works. Embeds (Spotify, YouTube) are happier over http.

## Language

EN, SV, DE and FR. The choice is stored as `kb-lang` in localStorage. On a first visit the page follows `navigator.language`.

Live domain: https://karolinabengtsson.com


## Publicera

Ladda upp innehållet i den här mappen till webbhotellet, så att `index.html` ligger i webbrotten. Apache läser `.htaccess`. Ingen build behövs.
