/* First visit: browser language. After that, whatever they last picked. */
const LANGS = ["en", "sv", "de", "fr"];
const STORE = "kb-lang";

function M(value, lang) {
  if (value == null) return "";
  if (typeof value === "string") return value;
  return value[lang] || value.en || "";
}

const COPY = {
  "skip": {
    "en": "Skip to content",
    "sv": "Hoppa till innehållet",
    "de": "Zum Inhalt",
    "fr": "Aller au contenu"
  },
  "soprano": {
    "en": "Soprano",
    "sv": "Sopran",
    "de": "Sopran",
    "fr": "Soprano"
  },
  "menu": {
    "en": "Menu",
    "sv": "Meny",
    "de": "Menü",
    "fr": "Menu"
  },
  "menuClose": {
    "en": "Close",
    "sv": "Stäng",
    "de": "Schließen",
    "fr": "Fermer"
  },
  "langLabel": {
    "en": "Language",
    "sv": "Språk",
    "de": "Sprache",
    "fr": "Langue"
  },
  "navLabel": {
    "en": "Sections",
    "sv": "Avsnitt",
    "de": "Abschnitte",
    "fr": "Sections"
  },
  "newtab": {
    "en": " (opens in a new tab)",
    "sv": " (öppnas i ny flik)",
    "de": " (öffnet in neuem Tab)",
    "fr": " (s'ouvre dans un nouvel onglet)"
  },
  "title": {
    "en": "Karolina Bengtsson, Soprano",
    "sv": "Karolina Bengtsson, sopran",
    "de": "Karolina Bengtsson, Sopranistin",
    "fr": "Karolina Bengtsson, soprano"
  },
  "desc": {
    "en": "Karolina Bengtsson, Swedish soprano. Member of the soloist ensemble at Oper Frankfurt, Birgit Nilsson Stipendiat 2025. Biography, chronology, repertoire and season 2026/27.",
    "sv": "Karolina Bengtsson, svensk sopran. Medlem av Oper Frankfurts solistensemble, Birgit Nilsson-stipendiat 2025. Biografi, kronologi, repertoar och säsongen 2026/27.",
    "de": "Karolina Bengtsson, schwedische Sopranistin. Mitglied des Solistenensembles der Oper Frankfurt, Birgit-Nilsson-Stipendiatin 2025. Biographie, Chronologie, Repertoire und Spielzeit 2026/27.",
    "fr": "Karolina Bengtsson, soprano suédoise. Membre de la troupe de solistes de l'Oper Frankfurt, lauréate du Birgit Nilsson Stipendium 2025. Biographie, chronologie, répertoire et saison 2026/27."
  },
  "nav": {
    "news": {
      "en": "News",
      "sv": "Nyheter",
      "de": "Aktuelles",
      "fr": "Actualités"
    },
    "biography": {
      "en": "Biography",
      "sv": "Biografi",
      "de": "Biographie",
      "fr": "Biographie"
    },
    "timeline": {
      "en": "Chronology",
      "sv": "Kronologi",
      "de": "Chronologie",
      "fr": "Chronologie"
    },
    "repertoire": {
      "en": "Repertoire",
      "sv": "Repertoar",
      "de": "Repertoire",
      "fr": "Répertoire"
    },
    "season": {
      "en": "Season",
      "sv": "Säsong",
      "de": "Spielzeit",
      "fr": "Saison"
    },
    "media": {
      "en": "Music",
      "sv": "Musik",
      "de": "Musik",
      "fr": "Musique"
    },
    "gallery": {
      "en": "Gallery",
      "sv": "Galleri",
      "de": "Galerie",
      "fr": "Galerie"
    },
    "press": {
      "en": "Press",
      "sv": "Press",
      "de": "Presse",
      "fr": "Presse"
    },
    "contact": {
      "en": "Contact",
      "sv": "Kontakt",
      "de": "Kontakt",
      "fr": "Contact"
    }
  },
  "opening": {
    "house": "Oper Frankfurt",
    "from": {
      "en": "Oper Frankfurt",
      "sv": "Oper Frankfurt",
      "de": "Oper Frankfurt",
      "fr": "Oper Frankfurt"
    },
    "lineShort": {
      "en": "Birgit Nilsson Stipendiat 2025",
      "sv": "Birgit Nilsson-stipendiat 2025",
      "de": "Birgit-Nilsson-Stipendiatin 2025",
      "fr": "Lauréate du Birgit Nilsson Stipendium 2025"
    },
    "ctaSeason": {
      "en": "See the season",
      "sv": "Se säsongen",
      "de": "Zur Spielzeit",
      "fr": "Voir la saison"
    },
    "ctaTickets": {
      "en": "Tickets",
      "sv": "Biljetter",
      "de": "Karten",
      "fr": "Billets"
    },
    "lead1": {
      "en": "This season",
      "sv": "Denna säsong",
      "de": "In dieser Spielzeit",
      "fr": "Cette saison"
    },
    "lead2": {
      "en": "at Oper Frankfurt",
      "sv": "på Oper Frankfurt",
      "de": "an der Oper Frankfurt",
      "fr": "à l'Oper Frankfurt"
    },
    "line": {
      "en": "in <em>Così fan tutte</em> at Oper Frankfurt, 23 Aug – 21 Jan",
      "sv": "i <em>Così fan tutte</em> på Oper Frankfurt, 23 aug – 21 jan",
      "de": "in <em>Così fan tutte</em> an der Oper Frankfurt, 23. Aug. – 21. Jan",
      "fr": "dans <em>Così fan tutte</em> à l'Oper Frankfurt, 23 août – 21 janv"
    },
    "ticketsPre": {
      "en": "Tickets at ",
      "sv": "Biljetter på ",
      "de": "Karten über ",
      "fr": "Billets sur "
    },
    "bio": {
      "en": "Swedish soprano, member of the soloist ensemble at Oper Frankfurt and Birgit Nilsson Stipendiat 2025.",
      "sv": "Svensk sopran, medlem av Oper Frankfurts solistensemble och Birgit Nilsson-stipendiat 2025.",
      "de": "Schwedische Sopranistin, Mitglied des Solistenensembles der Oper Frankfurt und Birgit-Nilsson-Stipendiatin 2025.",
      "fr": "Soprano suédoise, membre de la troupe de solistes de l'Oper Frankfurt et lauréate du Birgit Nilsson Stipendium 2025."
    },
    "alt": {
      "en": "Karolina Bengtsson as Fiordiligi in Così fan tutte, Oper Frankfurt",
      "sv": "Karolina Bengtsson som Fiordiligi i Così fan tutte, Oper Frankfurt",
      "de": "Karolina Bengtsson als Fiordiligi in Così fan tutte, Oper Frankfurt",
      "fr": "Karolina Bengtsson en Fiordiligi dans Così fan tutte, Oper Frankfurt"
    },
    "cap": "Così fan tutte, Oper Frankfurt",
    "portraitAlt": {
      "en": "Karolina Bengtsson, soprano",
      "sv": "Karolina Bengtsson, sopran",
      "de": "Karolina Bengtsson, Sopranistin",
      "fr": "Karolina Bengtsson, soprano"
    }
  },
  "news": {
    "title": {
      "en": "News",
      "sv": "Nyheter",
      "de": "Aktuelles",
      "fr": "Actualités"
    },
    "note": {
      "en": "The latest news and engagements",
      "sv": "Det senaste om Karolina Bengtsson",
      "de": "Das Neueste über Karolina Bengtsson",
      "fr": "Les dernières nouvelles de Karolina Bengtsson"
    },
    "more": {
      "en": "Earlier news",
      "sv": "Tidigare nyheter",
      "de": "Frühere Meldungen",
      "fr": "Actualités précédentes"
    }
  },
  "bio": {
    "title": {
      "en": "Biography",
      "sv": "Biografi",
      "de": "Biographie",
      "fr": "Biographie"
    },
    "note": {
      "en": "Biography & background",
      "sv": "Biografi & bakgrund",
      "de": "Biographie & Hintergrund",
      "fr": "Biographie & parcours"
    },
    "p1": {
      "en": "Karolina Bengtsson was born in 1997 and grew up in Huseby, Småland. She studied at the Royal Danish Academy of Music in Copenhagen and took her master’s with Barbara Bonney at the Mozarteum in Salzburg in 2023. She studied Lied with Wolfgang Holzmair.",
      "sv": "Karolina Bengtsson föddes 1997 och växte upp i Huseby, en bruksort i Småland. Hon studerade vid Det Kongelige Danske Musikkonservatorium i Köpenhamn och tog master för Barbara Bonney vid Mozarteum i Salzburg 2023. I romans arbetade hon med Wolfgang Holzmair.",
      "de": "Karolina Bengtsson, geboren 1997, wuchs in Huseby in Småland auf. Sie studierte an der Königlich Dänischen Musikakademie in Kopenhagen und machte 2023 ihren Master bei Barbara Bonney am Mozarteum in Salzburg. Lied bei Wolfgang Holzmair.",
      "fr": "Karolina Bengtsson est née en 1997 et a grandi à Huseby, dans le Småland. Elle a étudié à l'Académie royale danoise de musique à Copenhague et a passé son master en 2023 avec Barbara Bonney au Mozarteum de Salzbourg. Le lied, elle l'a travaillé avec Wolfgang Holzmair."
    },
    "p2": {
      "en": "She came to the Opera Studio in Frankfurt in 2021 and has been in the ensemble since 2023. She has sung at the Bayerische Staatsoper, the Festival d’Aix-en-Provence and the Innsbruck Festival of Early Music, and in concert with the Swedish Radio Symphony Orchestra and the Gothenburg Symphony Orchestra.",
      "sv": "2021 kom hon till operastudion i Frankfurt. Sedan 2023 sjunger hon i solistensemblen. Hon har gästat Bayerische Staatsoper, Festival d’Aix-en-Provence och Innsbrucker Festwochen, och sjungit med Sveriges Radios symfoniorkester och Göteborgs Symfoniker.",
      "de": "2021 kam sie ins Opernstudio in Frankfurt. Seit 2023 singt sie im Solistenensemble. Sie war an der Bayerischen Staatsoper, beim Festival d’Aix-en-Provence und bei den Innsbrucker Festwochen, im Konzert beim Schwedischen Rundfunk-Sinfonieorchester und bei den Göteborger Symphonikern.",
      "fr": "Elle est arrivée à l'Opera Studio de Francfort en 2021 et chante dans la troupe depuis 2023. Elle a été à la Bayerische Staatsoper, au Festival d’Aix-en-Provence et aux Innsbrucker Festwochen, et en concert avec l'Orchestre symphonique de la Radio suédoise et l'Orchestre symphonique de Göteborg."
    },
    "figcap": {
      "en": "Portrait, Tore Sjöqvist",
      "sv": "Foto: Tore Sjöqvist",
      "de": "Porträt, Tore Sjöqvist",
      "fr": "Portrait, Tore Sjöqvist"
    },
    "alt": {
      "en": "Karolina Bengtsson by a lake",
      "sv": "Karolina Bengtsson vid en sjö",
      "de": "Karolina Bengtsson an einem See",
      "fr": "Karolina Bengtsson au bord d'un lac"
    },
    "quote": {
      "en": "What an honour! It feels incredible to be awarded the Birgit Nilsson Stipendium. Beyond the honour, it is also a recognition and an encouragement to keep following my dream.",
      "sv": "Vilken ära! Det känns otroligt stort att tilldelas Birgit Nilsson-stipendiet. Förutom äran är det också ett erkännande och en uppmuntran att fortsätta följa min dröm.",
      "de": "Was für eine Ehre! Es fühlt sich unglaublich groß an, mit dem Birgit-Nilsson-Stipendium ausgezeichnet zu werden. Neben der Ehre ist es auch eine Anerkennung und eine Ermutigung, meinem Traum weiter zu folgen.",
      "fr": "Quel honneur ! C'est un sentiment incroyable de recevoir le Birgit Nilsson Stipendium. Au-delà de l'honneur, c'est aussi une reconnaissance et un encouragement à continuer de suivre mon rêve."
    },
    "attribution": {
      "en": "On receiving the Birgit Nilsson Stipendium, 2025",
      "sv": "Vid mottagandet av Birgit Nilsson-stipendiet 2025",
      "de": "Zur Verleihung des Birgit-Nilsson-Stipendiums 2025",
      "fr": "À la réception du Birgit Nilsson Stipendium, 2025"
    }
  },
  "chrono": {
    "title": {
      "en": "Chronology",
      "sv": "Kronologi",
      "de": "Chronologie",
      "fr": "Chronologie"
    },
    "note": {
      "en": "Roles and prizes, 2017–2027",
      "sv": "Roller och priser 2017–2027",
      "de": "Partien und Preise 2017–2027",
      "fr": "Rôles et prix 2017–2027"
    },
    "prize": {
      "en": "Prize",
      "sv": "Pris",
      "de": "Preis",
      "fr": "Prix"
    },
    "viewFull": {
      "en": "View full chronology",
      "sv": "Visa hela kronologin",
      "de": "Vollständige Chronologie",
      "fr": "Voir la chronologie complète"
    }
  },
  "stipend": {
    "title": {
      "en": "Birgit Nilsson Stipendium 2025",
      "sv": "Birgit Nilsson-stipendiet 2025",
      "de": "Birgit Nilsson Stipendium 2025",
      "fr": "Birgit Nilsson Stipendium 2025"
    },
    "eyebrow": {
      "en": "Award",
      "sv": "Utmärkelse",
      "de": "Auszeichnung",
      "fr": "Distinction"
    },
    "line1": {
      "en": "Birgit Nilsson",
      "sv": "Birgit Nilsson",
      "de": "Birgit Nilsson",
      "fr": "Birgit Nilsson"
    },
    "line2": {
      "en": "Stipendium 2025",
      "sv": "Stipendium 2025",
      "de": "Stipendium 2025",
      "fr": "Stipendium 2025"
    },
    "body": {
      "en": "Founded by Birgit Nilsson in 1973 in memory of her first teacher, Ragnar Blennow, and awarded to outstanding young Swedish singers ever since. The 2025 recital was given in Birgit Nilsson’s own church in Västra Karup on 8 August, during the Birgit Nilsson Festival.",
      "sv": "Instiftat av Birgit Nilsson 1973 till minne av hennes första lärare, Ragnar Blennow, och sedan dess tilldelat framstående unga svenska sångare. 2025 års stipendiekonsert gavs i Birgit Nilssons egen kyrka i Västra Karup den 8 augusti, under Birgit Nilsson-festivalen.",
      "de": "1973 von Birgit Nilsson im Gedenken an ihren ersten Lehrer Ragnar Blennow gestiftet und seither an herausragende junge schwedische Sängerinnen und Sänger vergeben. Das Konzert 2025 fand am 8. August in Birgit Nilssons eigener Kirche in Västra Karup statt, im Rahmen des Birgit-Nilsson-Festivals.",
      "fr": "Fondé par Birgit Nilsson en 1973 à la mémoire de son premier professeur, Ragnar Blennow, et décerné depuis à de jeunes chanteurs suédois d'exception. Le récital 2025 a été donné le 8 août dans l'église de Birgit Nilsson à Västra Karup, dans le cadre du Birgit Nilsson Festival."
    },
    "award": {
      "en": "Awarded the 2025 Birgit Nilsson Stipendium of SEK 250,000, announced in May at the Birgit Nilsson Museum.",
      "sv": "Tilldelad 2025 års Birgit Nilsson-stipendium på 250 000 kronor, tillkännagivet i maj på Birgit Nilsson Museum.",
      "de": "Ausgezeichnet mit dem Birgit-Nilsson-Stipendium 2025 über 250 000 SEK, verkündet im Mai im Birgit-Nilsson-Museum.",
      "fr": "Lauréate du Birgit Nilsson Stipendium 2025, doté de 250 000 SEK et annoncé en mai au musée Birgit Nilsson."
    }
  },
  "rep": {
    "title": {
      "en": "Repertoire",
      "sv": "Repertoar",
      "de": "Repertoire",
      "fr": "Répertoire"
    },
    "note": {
      "en": "Open a role for production details",
      "sv": "Öppna en roll för produktionsinformation",
      "de": "Eine Partie öffnen für Details zur Produktion",
      "fr": "Ouvrez un rôle pour le détail de la production"
    },
    "opera": {
      "en": "Opera",
      "sv": "Opera",
      "de": "Oper",
      "fr": "Opéra"
    },
    "concert": {
      "en": "Concert & Lied",
      "sv": "Konsert & romans",
      "de": "Konzert & Lied",
      "fr": "Concert & mélodie"
    },
    "bottom": {
      "en": "Concert engagements include the Swedish Radio Symphony Orchestra and the Gothenburg Symphony Orchestra. Full repertoire on request.",
      "sv": "Konsertengagemang inkluderar Sveriges Radios symfoniorkester och Göteborgs Symfoniker. Fullständig repertoar på förfrågan.",
      "de": "Zu ihren Konzertengagements zählen das Schwedische Rundfunk-Sinfonieorchester und die Göteborger Symphoniker. Vollständiges Repertoire auf Anfrage.",
      "fr": "Elle s'est produite en concert avec l'Orchestre symphonique de la Radio suédoise et l'Orchestre symphonique de Göteborg. Répertoire complet sur demande."
    },
    "composer": {
      "en": "Composer",
      "sv": "Tonsättare",
      "de": "Komponist",
      "fr": "Compositeur"
    },
    "conductor": {
      "en": "Conductor",
      "sv": "Dirigent",
      "de": "Dirigent",
      "fr": "Direction"
    },
    "director": {
      "en": "Director",
      "sv": "Regi",
      "de": "Regie",
      "fr": "Mise en scène"
    },
    "withWho": {
      "en": "With",
      "sv": "Med",
      "de": "Mit",
      "fr": "Avec"
    },
    "about": {
      "en": "About the production",
      "sv": "Om produktionen",
      "de": "Zur Produktion",
      "fr": "Sur la production"
    },
    "viewFull": {
      "en": "View full repertoire",
      "sv": "Visa hela repertoaren",
      "de": "Vollständiges Repertoire",
      "fr": "Voir le répertoire complet"
    }
  },
  "season": {
    "title": {
      "en": "Season 2026/27",
      "sv": "Säsong 2026/27",
      "de": "Spielzeit 2026/27",
      "fr": "Saison 2026/27"
    },
    "note": {
      "en": "Spielzeit 2026/27",
      "sv": "Spelåret 2026/27",
      "de": "2026/27",
      "fr": "Saison 2026/27"
    },
    "flag": {
      "en": "Premiere",
      "sv": "Premiär",
      "de": "Premiere",
      "fr": "Création"
    },
    "alt": {
      "en": "The Alte Oper in Frankfurt am Main at night",
      "sv": "Alte Oper i Frankfurt am Main om natten",
      "de": "Die Alte Oper in Frankfurt am Main bei Nacht",
      "fr": "L'Alte Oper de Francfort-sur-le-Main, de nuit"
    },
    "trioAlt": {
      "en": "Karolina Bengtsson as Fiordiligi in Così fan tutte, Oper Frankfurt",
      "sv": "Karolina Bengtsson som Fiordiligi i Così fan tutte, Oper Frankfurt",
      "de": "Karolina Bengtsson als Fiordiligi in Così fan tutte, Oper Frankfurt",
      "fr": "Karolina Bengtsson en Fiordiligi dans Così fan tutte, Oper Frankfurt"
    },
    "noteText": {
      "en": "Tickets open the Oper Frankfurt page for that production.",
      "sv": "Biljettlänken går till respektive produktion på Oper Frankfurt.",
      "de": "Die Kartenlinks führen zur jeweiligen Produktion der Oper Frankfurt.",
      "fr": "Les liens billets ouvrent la page de chaque production à l'Oper Frankfurt."
    },
    "venue": "Oper Frankfurt",
    "colDate": {
      "en": "Date",
      "sv": "Datum",
      "de": "Datum",
      "fr": "Date"
    },
    "colWork": {
      "en": "Work",
      "sv": "Verk",
      "de": "Werk",
      "fr": "Œuvre"
    },
    "colRole": {
      "en": "Role",
      "sv": "Roll",
      "de": "Partie",
      "fr": "Rôle"
    },
    "colVenue": {
      "en": "Venue",
      "sv": "Scen",
      "de": "Haus",
      "fr": "Scène"
    },
    "colTickets": {
      "en": "Tickets",
      "sv": "Biljetter",
      "de": "Karten",
      "fr": "Billets"
    },
    "tickets": {
      "en": "Tickets",
      "sv": "Biljetter",
      "de": "Karten",
      "fr": "Billets"
    }
  },
  "media": {
    "title": {
      "en": "Music & Video",
      "sv": "Musik & video",
      "de": "Musik & Video",
      "fr": "Musique & vidéo"
    },
    "recKicker": {
      "en": "Her first recording",
      "sv": "Hennes första skiva",
      "de": "Ihre erste Aufnahme",
      "fr": "Son premier enregistrement"
    },
    "albumMeta": {
      "en": "Tommaso Traetta, world premiere recording. Aparté, 2026",
      "sv": "Tommaso Traetta, världspremiärinspelning. Aparté, 2026",
      "de": "Tommaso Traetta, Weltersteinspielung. Aparté, 2026",
      "fr": "Tommaso Traetta, premier enregistrement mondial. Aparté, 2026"
    },
    "albumBody": {
      "en": "Recorded at the 2025 Innsbrucker Festwochen der Alten Musik with Les Talens Lyriques under Christophe Rousset. Karolina sings Dori alongside Rocío Pérez and Rafał Tomkiewicz. In August 2026 the recording was named on the Bestenliste of the Preis der deutschen Schallplattenkritik.",
      "sv": "Inspelad vid Innsbrucker Festwochen der Alten Musik 2025 med Les Talens Lyriques under Christophe Rousset. Karolina sjunger Dori vid sidan av Rocío Pérez och Rafał Tomkiewicz. I augusti 2026 togs inspelningen upp på Bestenliste av Preis der deutschen Schallplattenkritik.",
      "de": "Aufgenommen bei den Innsbrucker Festwochen der Alten Musik 2025 mit Les Talens Lyriques unter Christophe Rousset. Karolina singt die Dori an der Seite von Rocío Pérez und Rafał Tomkiewicz. Im August 2026 wurde die Aufnahme auf die Bestenliste des Preises der deutschen Schallplattenkritik gesetzt.",
      "fr": "Enregistré aux Innsbrucker Festwochen der Alten Musik 2025 avec Les Talens Lyriques sous la direction de Christophe Rousset. Karolina y chante Dori aux côtés de Rocío Pérez et Rafał Tomkiewicz. En août 2026, l'enregistrement a été inscrit sur la Bestenliste du Preis der deutschen Schallplattenkritik."
    },
    "filmKicker": {
      "en": "On film",
      "sv": "På film",
      "de": "Im Film",
      "fr": "En images"
    },
    "cap1": {
      "en": "Death and Juliet, Daniel Nelson. With Malin Broman and Musica Vitae.",
      "sv": "Döden & Julia av Daniel Nelson. Med Malin Broman och Musica Vitae.",
      "de": "Death and Juliet von Daniel Nelson. Mit Malin Broman und Musica Vitae.",
      "fr": "Death and Juliet de Daniel Nelson. Avec Malin Broman et Musica Vitae."
    },
    "cap2": {
      "en": "Ascanio in Alba, trailer. Oper Frankfurt 2023; Karolina as Silvia.",
      "sv": "Ascanio in Alba, trailer. Oper Frankfurt 2023; Karolina som Silvia.",
      "de": "Ascanio in Alba, Trailer. Oper Frankfurt 2023; Karolina als Silvia.",
      "fr": "Ascanio in Alba, bande-annonce. Oper Frankfurt 2023 ; Karolina en Silvia."
    },
    "more1": {
      "en": "More video on ",
      "sv": "Fler filmer på ",
      "de": "Mehr Videos auf ",
      "fr": "Plus de vidéos sur "
    },
    "moreYt": {
      "en": "her YouTube channel",
      "sv": "hennes YouTube-kanal",
      "de": "ihrem YouTube-Kanal",
      "fr": "sa chaîne YouTube"
    },
    "more2": {
      "en": " and at ",
      "sv": " och hos ",
      "de": " und bei ",
      "fr": " et chez "
    },
    "loadAlbum": {
      "en": "Load recording: Ifigenia in Tauride",
      "sv": "Ladda inspelningen: Ifigenia in Tauride",
      "de": "Aufnahme laden: Ifigenia in Tauride",
      "fr": "Charger l'enregistrement : Ifigenia in Tauride"
    },
    "load1": {
      "en": "Load film: Death and Juliet",
      "sv": "Ladda filmen: Döden & Julia",
      "de": "Film laden: Death and Juliet",
      "fr": "Charger le film : Death and Juliet"
    },
    "load2": {
      "en": "Load film: Ascanio in Alba",
      "sv": "Ladda filmen: Ascanio in Alba",
      "de": "Film laden: Ascanio in Alba",
      "fr": "Charger le film : Ascanio in Alba"
    },
    "listenSpotify": {
      "en": "Listen on Spotify",
      "sv": "Lyssna på Spotify",
      "de": "Auf Spotify hören",
      "fr": "Écouter sur Spotify"
    },
    "playHere": {
      "en": "Play here",
      "sv": "Spela här",
      "de": "Hier abspielen",
      "fr": "Lire ici"
    },
    "playFilm": {
      "en": "Play",
      "sv": "Spela",
      "de": "Abspielen",
      "fr": "Lire"
    }
  },
  "gallery": {
    "title": {
      "en": "Gallery",
      "sv": "Galleri",
      "de": "Galerie",
      "fr": "Galerie"
    },
    "note": {
      "en": "On stage and in portrait",
      "sv": "På scen och i porträtt",
      "de": "Auf der Bühne und im Porträt",
      "fr": "Sur scène et en portrait"
    },
    "stage": {
      "en": "On stage",
      "sv": "På scen",
      "de": "Auf der Bühne",
      "fr": "Sur scène"
    },
    "smaland": "Porträtt",
    "throneAlt": {
      "en": "Karolina Bengtsson as Belisa in In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt",
      "sv": "Karolina Bengtsson som Belisa i In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt",
      "de": "Karolina Bengtsson als Belisa in In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt",
      "fr": "Karolina Bengtsson en Belisa dans In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt"
    },
    "annaAlt": {
      "en": "Karolina Bengtsson as Anna in Blühen, Oper Frankfurt",
      "sv": "Karolina Bengtsson som Anna i Blühen, Oper Frankfurt",
      "de": "Karolina Bengtsson als Anna in Blühen, Oper Frankfurt",
      "fr": "Karolina Bengtsson en Anna dans Blühen, Oper Frankfurt"
    },
    "belisaAlt": {
      "en": "Karolina Bengtsson as Belisa in In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt",
      "sv": "Karolina Bengtsson som Belisa i In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt",
      "de": "Karolina Bengtsson als Belisa in In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt",
      "fr": "Karolina Bengtsson en Belisa dans In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt"
    },
    "alt1": {
      "en": "Karolina Bengtsson in a yellow dress in a beech forest",
      "sv": "Karolina Bengtsson i gul klänning i en bokskog",
      "de": "Karolina Bengtsson im gelben Kleid in einem Buchenwald",
      "fr": "Karolina Bengtsson en robe jaune dans une hêtraie"
    },
    "alt2": {
      "en": "Karolina Bengtsson at a gate in the countryside",
      "sv": "Karolina Bengtsson vid en grind på landet",
      "de": "Karolina Bengtsson an einem Tor auf dem Land",
      "fr": "Karolina Bengtsson devant un portail à la campagne"
    },
    "alt3": {
      "en": "Karolina Bengtsson seated by a stone wall",
      "sv": "Karolina Bengtsson vid en stenmur",
      "de": "Karolina Bengtsson an einer Steinmauer",
      "fr": "Karolina Bengtsson près d'un mur de pierre"
    },
    "alt4": {
      "en": "Karolina Bengtsson by a moss-grown tree",
      "sv": "Karolina Bengtsson vid ett mossbeklätt träd",
      "de": "Karolina Bengtsson an einem bemoosten Baum",
      "fr": "Karolina Bengtsson près d'un arbre moussu"
    },
    "briefAlt": {
      "en": "Karolina Bengtsson as Fiordiligi in Così fan tutte, Oper Frankfurt",
      "sv": "Karolina Bengtsson som Fiordiligi i Così fan tutte, Oper Frankfurt",
      "de": "Karolina Bengtsson als Fiordiligi in Così fan tutte, Oper Frankfurt",
      "fr": "Karolina Bengtsson en Fiordiligi dans Così fan tutte, Oper Frankfurt"
    },
    "viewFull": {
      "en": "More photographs",
      "sv": "Fler fotografier",
      "de": "Weitere Fotografien",
      "fr": "Autres photographies"
    }
  },
  "contact": {
    "title": {
      "en": "Contact",
      "sv": "Kontakt",
      "de": "Kontakt",
      "fr": "Contact"
    },
    "mgmt": {
      "en": "General management",
      "sv": "Management",
      "de": "Management",
      "fr": "Management général"
    },
    "manager": {
      "en": "Elisabeth Haglund, Artist Manager",
      "sv": "Elisabeth Haglund, artistagent",
      "de": "Elisabeth Haglund, Künstleragentin",
      "fr": "Elisabeth Haglund, agente artistique"
    },
    "links": {
      "en": "Links",
      "sv": "Länkar",
      "de": "Links",
      "fr": "Liens"
    },
    "l1": {
      "en": "Profile at Oper Frankfurt",
      "sv": "Profil hos Oper Frankfurt",
      "de": "Profil bei der Oper Frankfurt",
      "fr": "Profil à l'Oper Frankfurt"
    },
    "l2": {
      "en": "Artist page at Braathen Management",
      "sv": "Artistsida hos Braathen Management",
      "de": "Künstlerseite bei Braathen Management",
      "fr": "Page d'artiste chez Braathen Management"
    },
    "l3": {
      "en": "Schedule on Operabase",
      "sv": "Spelschema på Operabase",
      "de": "Termine auf Operabase",
      "fr": "Calendrier sur Operabase"
    },
    "press": {
      "en": "Press photos, biography and CV are in the <a href=\"#press\">press section</a>. For other material, contact the management.",
      "sv": "Pressbilder, biografi och CV finns under <a href=\"#press\">Press</a>. Övrigt material via management.",
      "de": "Pressefotos, Biographie und Lebenslauf finden sich unter <a href=\"#press\">Presse</a>. Weiteres Material über das Management.",
      "fr": "Photos de presse, biographie et CV se trouvent dans la rubrique <a href=\"#press\">Presse</a>. Pour tout autre document, s'adresser au management."
    }
  },
  "press": {
    "title": {
      "en": "Press",
      "sv": "Press",
      "de": "Presse",
      "fr": "Presse"
    },
    "lead": {
      "en": "Short and long biography, CV and stage photos. Credit the photographer.",
      "sv": "Kort och lång biografi, CV och scenbilder. Skriv fotografens namn.",
      "de": "Kurze und lange Biographie, Lebenslauf und Bühnenfotos. Den Fotografen bitte nennen.",
      "fr": "Biographie courte et longue, CV et photos de scène. Indiquer le nom du photographe."
    },
    "shortTitle": {
      "en": "Short biography",
      "sv": "Kort biografi",
      "de": "Kurzbiographie",
      "fr": "Biographie courte"
    },
    "longTitle": {
      "en": "Long biography",
      "sv": "Lång biografi",
      "de": "Langbiographie",
      "fr": "Biographie longue"
    },
    "cvTitle": {
      "en": "Curriculum vitae",
      "sv": "CV",
      "de": "Lebenslauf",
      "fr": "CV"
    },
    "photosTitle": {
      "en": "Press photographs",
      "sv": "Pressbilder",
      "de": "Pressefotos",
      "fr": "Photos de presse"
    },
    "download": {
      "en": "Download",
      "sv": "Ladda ner",
      "de": "Download",
      "fr": "Télécharger"
    },
    "downloadShort": {
      "en": "Download short biography",
      "sv": "Ladda ner kort biografi",
      "de": "Kurzbiographie herunterladen",
      "fr": "Télécharger la biographie courte"
    },
    "downloadLong": {
      "en": "Download long biography",
      "sv": "Ladda ner lång biografi",
      "de": "Langbiographie herunterladen",
      "fr": "Télécharger la biographie longue"
    },
    "openCv": {
      "en": "Open CV",
      "sv": "Öppna CV",
      "de": "Lebenslauf öffnen",
      "fr": "Ouvrir le CV"
    },
    "downloadCv": {
      "en": "Download CV (PDF)",
      "sv": "Ladda ner CV (PDF)",
      "de": "Lebenslauf als PDF",
      "fr": "Télécharger le CV (PDF)"
    },
    "short": {
      "en": "Karolina Bengtsson is a soprano in the ensemble at Oper Frankfurt. She received the Birgit Nilsson Stipendium in 2025. In Frankfurt in 2026/27 she sings Fiordiligi in Così fan tutte, the title role in Zaide, Gretel in Hänsel und Gretel and Oberto in Alcina. First record: Traetta, Ifigenia in Tauride, Les Talens Lyriques, Christophe Rousset (Aparté, 2026). Bestenliste, Preis der deutschen Schallplattenkritik.",
      "sv": "Karolina Bengtsson är sopran i ensemblen vid Oper Frankfurt. Hon fick Birgit Nilsson-stipendiet 2025. I Frankfurt 2026/27 sjunger hon Fiordiligi i Così fan tutte, titelrollen i Zaide, Gretel i Hänsel und Gretel och Oberto i Alcina. Första skivan: Traetta, Ifigenia in Tauride, Les Talens Lyriques, Christophe Rousset (Aparté, 2026). Bestenliste, Preis der deutschen Schallplattenkritik.",
      "de": "Karolina Bengtsson ist Sopranistin im Ensemble der Oper Frankfurt. 2025 erhielt sie das Birgit-Nilsson-Stipendium. In Frankfurt singt sie 2026/27 Fiordiligi in Così fan tutte, die Titelpartie in Zaide, Gretel in Hänsel und Gretel und Oberto in Alcina. Erste Platte: Traetta, Ifigenia in Tauride, Les Talens Lyriques, Christophe Rousset (Aparté, 2026). Bestenliste, Preis der deutschen Schallplattenkritik.",
      "fr": "Karolina Bengtsson est soprano à l'Oper Frankfurt. Elle a reçu le Birgit Nilsson Stipendium en 2025. À Francfort en 2026/27, elle chante Fiordiligi dans Così fan tutte, le rôle-titre de Zaide, Gretel dans Hänsel und Gretel et Oberto dans Alcina. Premier disque : Traetta, Ifigenia in Tauride, Les Talens Lyriques, Christophe Rousset (Aparté, 2026). Bestenliste, Preis der deutschen Schallplattenkritik."
    },
    "long": {
      "en": "Karolina Bengtsson was born in 1997 and grew up in Huseby, Småland. She studied at the Royal Danish Academy of Music in Copenhagen and took her master’s with Barbara Bonney at the Mozarteum in Salzburg in 2023. She studied Lied with Wolfgang Holzmair.\n\nShe came to the Opera Studio in Frankfurt in 2021 and has been in the ensemble since 2023. She has sung at the Bayerische Staatsoper, the Festival d’Aix-en-Provence and the Innsbruck Festival of Early Music, and in concert with the Swedish Radio Symphony Orchestra and the Gothenburg Symphony Orchestra.\n\nIn 2025 she received the Birgit Nilsson Stipendium. That summer she sang Camille in Louise in Aix and Dori in Traetta’s Ifigenia in Tauride in Innsbruck. The live recording came out on Aparté in 2026, with Les Talens Lyriques and Christophe Rousset. It is on the Bestenliste of the Preis der deutschen Schallplattenkritik and was reviewed in Gramophone.\n\nIn Frankfurt in 2026/27: Fiordiligi in Così fan tutte, the title role in Zaide, Gretel in Hänsel und Gretel and Oberto in Alcina.",
      "sv": "Karolina Bengtsson föddes 1997 och växte upp i Huseby, en bruksort i Småland. Hon studerade vid Det Kongelige Danske Musikkonservatorium i Köpenhamn och tog master för Barbara Bonney vid Mozarteum i Salzburg 2023. I romans arbetade hon med Wolfgang Holzmair.\n\n2021 kom hon till operastudion i Frankfurt. Sedan 2023 sjunger hon i solistensemblen. Hon har gästat Bayerische Staatsoper, Festival d’Aix-en-Provence och Innsbrucker Festwochen, och sjungit med Sveriges Radios symfoniorkester och Göteborgs Symfoniker.\n\n2025 fick hon Birgit Nilsson-stipendiet. Samma sommar sjöng hon Camille i Louise i Aix och Dori i Traettas Ifigenia in Tauride i Innsbruck. Liveinspelningen kom på Aparté 2026, med Les Talens Lyriques och Christophe Rousset. Den togs upp på Bestenliste hos Preis der deutschen Schallplattenkritik och recenserades i Gramophone.\n\nI Frankfurt 2026/27: Fiordiligi i Così fan tutte, titelrollen i Zaide, Gretel i Hänsel und Gretel och Oberto i Alcina.",
      "de": "Karolina Bengtsson, geboren 1997, wuchs in Huseby in Småland auf. Sie studierte an der Königlich Dänischen Musikakademie in Kopenhagen und machte 2023 ihren Master bei Barbara Bonney am Mozarteum in Salzburg. Lied bei Wolfgang Holzmair.\n\n2021 kam sie ins Opernstudio in Frankfurt. Seit 2023 singt sie im Solistenensemble. Sie war an der Bayerischen Staatsoper, beim Festival d’Aix-en-Provence und bei den Innsbrucker Festwochen, im Konzert beim Schwedischen Rundfunk-Sinfonieorchester und bei den Göteborger Symphonikern.\n\n2025 erhielt sie das Birgit-Nilsson-Stipendium. Im Sommer sang sie Camille in Louise in Aix und Dori in Traettas Ifigenia in Tauride in Innsbruck. Die Liveaufnahme erschien 2026 bei Aparté, mit Les Talens Lyriques und Christophe Rousset. Sie steht auf der Bestenliste des Preises der deutschen Schallplattenkritik und wurde in Gramophone besprochen.\n\nIn Frankfurt 2026/27: Fiordiligi in Così fan tutte, die Titelpartie in Zaide, Gretel in Hänsel und Gretel und Oberto in Alcina.",
      "fr": "Karolina Bengtsson est née en 1997 et a grandi à Huseby, dans le Småland. Elle a étudié à l'Académie royale danoise de musique à Copenhague et a passé son master en 2023 avec Barbara Bonney au Mozarteum de Salzbourg. Le lied, elle l'a travaillé avec Wolfgang Holzmair.\n\nElle est arrivée à l'Opera Studio de Francfort en 2021 et chante dans la troupe depuis 2023. Elle a été à la Bayerische Staatsoper, au Festival d’Aix-en-Provence et aux Innsbrucker Festwochen, et en concert avec l'Orchestre symphonique de la Radio suédoise et l'Orchestre symphonique de Göteborg.\n\nEn 2025, elle a reçu le Birgit Nilsson Stipendium. Cet été-là, elle a chanté Camille dans Louise à Aix et Dori dans Ifigenia in Tauride de Traetta à Innsbruck. L'enregistrement live est paru chez Aparté en 2026, avec Les Talens Lyriques et Christophe Rousset. Il est sur la Bestenliste du Preis der deutschen Schallplattenkritik et a été chroniqué dans Gramophone.\n\nÀ Francfort en 2026/27 : Fiordiligi dans Così fan tutte, le rôle-titre de Zaide, Gretel dans Hänsel und Gretel et Oberto dans Alcina."
    },
    "usage": {
      "en": "These files are for web and preview. Print originals are available from the management. Stage photos: Barbara Aumüller, Oper Frankfurt. Portrait: Tore Sjöqvist.",
      "sv": "Filerna är för webb och förhandsvisning. Tryckoriginal finns via management. Scenbilder: Barbara Aumüller, Oper Frankfurt. Porträtt: Tore Sjöqvist.",
      "de": "Die Dateien sind für Web und Vorschau. Druckvorlagen über das Management. Bühnenfotos: Barbara Aumüller, Oper Frankfurt. Porträt: Tore Sjöqvist.",
      "fr": "Ces fichiers sont destinés au web et à l'aperçu. Les originaux pour l'impression sont disponibles auprès du management. Photos de scène : Barbara Aumüller, Oper Frankfurt. Portrait : Tore Sjöqvist."
    }
  },
  "footer": {
    "top": {
      "en": "Back to top",
      "sv": "Till toppen",
      "de": "Nach oben",
      "fr": "Haut de page"
    }
  },
  "credit": {
    "portrait": {
      "en": "Photo: Tore Sjöqvist",
      "sv": "Foto: Tore Sjöqvist",
      "de": "Foto: Tore Sjöqvist",
      "fr": "Photo : Tore Sjöqvist"
    },
    "portraits": {
      "en": "Photos: Tore Sjöqvist",
      "sv": "Foto: Tore Sjöqvist",
      "de": "Fotos: Tore Sjöqvist",
      "fr": "Photos : Tore Sjöqvist"
    },
    "smaland": {
      "en": "Photo: Tore Sjöqvist",
      "sv": "Foto: Tore Sjöqvist",
      "de": "Foto: Tore Sjöqvist",
      "fr": "Photo : Tore Sjöqvist"
    },
    "stage": {
      "en": "Così fan tutte, Oper Frankfurt. Photo: Barbara Aumüller",
      "sv": "Così fan tutte, Oper Frankfurt. Foto: Barbara Aumüller",
      "de": "Così fan tutte, Oper Frankfurt. Foto: Barbara Aumüller",
      "fr": "Così fan tutte, Oper Frankfurt. Photo : Barbara Aumüller"
    },
    "anna": {
      "en": "Anna in Blühen, Oper Frankfurt. Photo: Barbara Aumüller",
      "sv": "Anna ur Blühen, Oper Frankfurt. Foto: Barbara Aumüller",
      "de": "Anna in Blühen, Oper Frankfurt. Foto: Barbara Aumüller",
      "fr": "Anna dans Blühen, Oper Frankfurt. Photo : Barbara Aumüller"
    },
    "belisa": {
      "en": "Belisa in In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt. Photo: Barbara Aumüller",
      "sv": "Belisa ur In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt. Foto: Barbara Aumüller",
      "de": "Belisa in In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt. Foto: Barbara Aumüller",
      "fr": "Belisa dans In seinem Garten liebt Don Perlimplín Belisa, Oper Frankfurt. Photo : Barbara Aumüller"
    },
    "footer": {
      "en": "Portraits: Tore Sjöqvist. Stage photographs: Barbara Aumüller, Oper Frankfurt.",
      "sv": "Porträtt: Tore Sjöqvist. Scenfotografier: Barbara Aumüller, Oper Frankfurt.",
      "de": "Porträts: Tore Sjöqvist. Bühnenfotos: Barbara Aumüller, Oper Frankfurt.",
      "fr": "Portraits : Tore Sjöqvist. Photos de scène : Barbara Aumüller, Oper Frankfurt."
    }
  },
  "secNum": {
    "news": "I",
    "biography": "II",
    "timeline": "III",
    "repertoire": "IV",
    "season": "V",
    "media": "VI",
    "gallery": "VII",
    "press": "VIII",
    "contact": "IX"
  }
};

const NEWS = [
  {
    "date": {
      "en": "Aug 2026",
      "sv": "aug 2026",
      "de": "Aug. 2026",
      "fr": "août 2026"
    },
    "display": "Bestenliste",
    "headline": {
      "en": "Named on the German Record Critics' Bestenliste",
      "sv": "Med på tyska skivkritikens Bestenliste",
      "de": "Auf der Bestenliste der deutschen Schallplattenkritik",
      "fr": "Au palmarès de la critique allemande du disque"
    },
    "flag": {
      "en": "Prize",
      "sv": "Pris",
      "de": "Preis",
      "fr": "Prix"
    },
    "body": {
      "en": "The recording of Traetta's <em>Ifigenia in Tauride</em> (Aparté), made at the 2025 Innsbrucker Festwochen with Les Talens Lyriques under Christophe Rousset, is placed on the <a href=\"https://www.schallplattenkritik.de/en/quarterly-critics-choice\">Bestenliste 3/2026</a> of the Preis der deutschen Schallplattenkritik. She shared the news <a href=\"https://www.instagram.com/p/DcA-4ZjjtjG/\">on Instagram</a>.",
      "sv": "Inspelningen av Traettas <em>Ifigenia in Tauride</em> (Aparté), gjord vid Innsbrucker Festwochen 2025 med Les Talens Lyriques under Christophe Rousset, har tagits upp på <a href=\"https://www.schallplattenkritik.de/en/quarterly-critics-choice\">Bestenliste 3/2026</a> av Preis der deutschen Schallplattenkritik. Hon delade nyheten <a href=\"https://www.instagram.com/p/DcA-4ZjjtjG/\">på Instagram</a>.",
      "de": "Die Aufnahme von Traettas <em>Ifigenia in Tauride</em> (Aparté), entstanden bei den Innsbrucker Festwochen 2025 mit Les Talens Lyriques unter Christophe Rousset, steht auf der <a href=\"https://www.schallplattenkritik.de/en/quarterly-critics-choice\">Bestenliste 3/2026</a> des Preises der deutschen Schallplattenkritik. Die Nachricht teilte sie <a href=\"https://www.instagram.com/p/DcA-4ZjjtjG/\">auf Instagram</a>.",
      "fr": "L'enregistrement d'<em>Ifigenia in Tauride</em> de Traetta (Aparté), réalisé aux Innsbrucker Festwochen 2025 avec Les Talens Lyriques sous la direction de Christophe Rousset, figure sur la <a href=\"https://www.schallplattenkritik.de/en/quarterly-critics-choice\">Bestenliste 3/2026</a> du Preis der deutschen Schallplattenkritik. Elle a partagé la nouvelle <a href=\"https://www.instagram.com/p/DcA-4ZjjtjG/\">sur Instagram</a>."
    }
  },
  {
    "date": {
      "en": "Mar 2026",
      "sv": "mars 2026",
      "de": "März 2026",
      "fr": "mars 2026"
    },
    "headline": {
      "en": "Debut recording released",
      "sv": "Debutskivan släppt",
      "de": "Debütaufnahme erschienen",
      "fr": "Parution du premier enregistrement"
    },
    "body": {
      "en": "Aparté issued <em>Ifigenia in Tauride</em>, the first recording of Traetta's opera, with Karolina as Dori. <a href=\"https://www.gramophone.co.uk/reviews/traetta-ifigenia-in-tauride-rousset\">Gramophone reviewed it in July 2026</a>. <a href=\"#media\">Hear it further down this page</a>.",
      "sv": "Aparté gav ut <em>Ifigenia in Tauride</em>, första inspelningen av Traettas opera, med Karolina som Dori. <a href=\"https://www.gramophone.co.uk/reviews/traetta-ifigenia-in-tauride-rousset\">Gramophone recenserade den i juli 2026</a>. <a href=\"#media\">Hör den längre ner på sidan</a>.",
      "de": "Aparté veröffentlichte <em>Ifigenia in Tauride</em>, die erste Aufnahme von Traettas Oper, mit Karolina als Dori. <a href=\"https://www.gramophone.co.uk/reviews/traetta-ifigenia-in-tauride-rousset\">Gramophone besprach sie im Juli 2026</a>. <a href=\"#media\">Zu hören weiter unten auf dieser Seite</a>.",
      "fr": "Aparté a publié <em>Ifigenia in Tauride</em>, le premier enregistrement de l'opéra de Traetta, avec Karolina dans le rôle de Dori. <a href=\"https://www.gramophone.co.uk/reviews/traetta-ifigenia-in-tauride-rousset\">Gramophone en a rendu compte en juillet 2026</a>. <a href=\"#media\">À écouter plus bas sur cette page</a>."
    }
  },
  {
    "date": {
      "en": "Jan 2026",
      "sv": "jan 2026",
      "de": "Jan. 2026",
      "fr": "janv. 2026"
    },
    "headline": {
      "en": "Role debut as Fiordiligi",
      "sv": "Rolldebut som Fiordiligi",
      "de": "Rollendebüt als Fiordiligi",
      "fr": "Prise de rôle en Fiordiligi"
    },
    "body": {
      "en": "A first Fiordiligi in <em>Così fan tutte</em> at Oper Frankfurt. She sings the role again when the revival opens <a href=\"#season\">the 2026/27 season</a> on 23 August.",
      "sv": "En första Fiordiligi i <em>Così fan tutte</em> på Oper Frankfurt. Hon sjunger rollen igen när nypremiären öppnar <a href=\"#season\">säsongen 2026/27</a> den 23 augusti.",
      "de": "Eine erste Fiordiligi in <em>Così fan tutte</em> an der Oper Frankfurt. Sie singt die Partie erneut, wenn die Wiederaufnahme am 23. August <a href=\"#season\">die Spielzeit 2026/27</a> eröffnet.",
      "fr": "Une première Fiordiligi dans <em>Così fan tutte</em> à l'Oper Frankfurt. Elle retrouvera le rôle lorsque la reprise ouvrira <a href=\"#season\">la saison 2026/27</a>, le 23 août."
    }
  },
  {
    "date": {
      "en": "Aug 2025",
      "sv": "aug 2025",
      "de": "Aug. 2025",
      "fr": "août 2025"
    },
    "headline": {
      "en": "Birgit Nilsson Stipendium recital in Västra Karup",
      "sv": "Stipendiekonsert i Västra Karups kyrka",
      "de": "Stipendiatenkonzert in Västra Karup",
      "fr": "Récital du Birgit Nilsson Stipendium à Västra Karup"
    },
    "body": {
      "en": "Awarded the 2025 <a href=\"https://birgitnilsson.com/stipendium/en/karolina-bengtsson-awarded-this-years-birgit-nilsson-stipendium/\">Birgit Nilsson Stipendium</a> of SEK 250,000, announced in May at the Birgit Nilsson Museum. The stipend recital was given in Birgit Nilsson's own church on 8 August, during the Birgit Nilsson Festival, where she also sang the Priestess in <em>Aida</em>.",
      "sv": "Tilldelad 2025 års <a href=\"https://birgitnilsson.com/stipendium/en/karolina-bengtsson-awarded-this-years-birgit-nilsson-stipendium/\">Birgit Nilsson-stipendium</a> på 250 000 kronor, tillkännagivet i maj på Birgit Nilsson Museum. Stipendiekonserten gavs i Birgit Nilssons egen kyrka den 8 augusti under Birgit Nilsson-festivalen, där hon även sjöng prästinnan i <em>Aida</em>.",
      "de": "Ausgezeichnet mit dem <a href=\"https://birgitnilsson.com/stipendium/en/karolina-bengtsson-awarded-this-years-birgit-nilsson-stipendium/\">Birgit-Nilsson-Stipendium</a> 2025 über 250 000 SEK, verkündet im Mai im Birgit-Nilsson-Museum. Das Stipendiatenkonzert fand am 8. August in Birgit Nilssons eigener Kirche statt, während des Birgit-Nilsson-Festivals, bei dem sie auch die Priesterin in <em>Aida</em> sang.",
      "fr": "Lauréate du <a href=\"https://birgitnilsson.com/stipendium/en/karolina-bengtsson-awarded-this-years-birgit-nilsson-stipendium/\">Birgit Nilsson Stipendium</a> 2025, doté de 250 000 SEK et annoncé en mai au musée Birgit Nilsson. Le récital a été donné le 8 août dans l'église de Birgit Nilsson, pendant le Birgit Nilsson Festival, où elle a aussi chanté la Prêtresse dans <em>Aida</em>."
    }
  },
  {
    "date": {
      "en": "Jul 2025",
      "sv": "juli 2025",
      "de": "Juli 2025",
      "fr": "juil. 2025"
    },
    "headline": {
      "en": "Debut at the Festival d'Aix-en-Provence",
      "sv": "Debut på Festival d'Aix-en-Provence",
      "de": "Debüt beim Festival d'Aix-en-Provence",
      "fr": "Débuts au Festival d'Aix-en-Provence"
    },
    "body": {
      "en": "Camille in Christof Loy's new production of Charpentier's <em>Louise</em>, conducted by Giacomo Sagripanti, with Elsa Dreisig in the title role.",
      "sv": "Camille i Christof Loys nyuppsättning av Charpentiers <em>Louise</em>, dirigerad av Giacomo Sagripanti, med Elsa Dreisig i titelrollen.",
      "de": "Camille in Christof Loys Neuinszenierung von Charpentiers <em>Louise</em> unter Giacomo Sagripanti, mit Elsa Dreisig in der Titelpartie.",
      "fr": "Camille dans la nouvelle production de <em>Louise</em> de Charpentier signée Christof Loy, sous la direction de Giacomo Sagripanti, avec Elsa Dreisig dans le rôle-titre."
    }
  }
];

const CHRONOLOGY = [
  {
    "year": "2026/27",
    "entries": [
      {
        "role": {
          "en": "Title role",
          "sv": "Titelrollen",
          "de": "Titelpartie",
          "fr": "Rôle-titre"
        },
        "work": "Zaide",
        "note": {
          "en": "premiere, Bockenheimer Depot",
          "sv": "premiär, Bockenheimer Depot",
          "de": "Premiere, Bockenheimer Depot",
          "fr": "création, Bockenheimer Depot"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Fiordiligi",
        "work": "Così fan tutte",
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Gretel",
        "work": "Hänsel und Gretel",
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Oberto",
        "work": "Alcina",
        "venue": "Oper Frankfurt"
      }
    ]
  },
  {
    "year": "2025/26",
    "entries": [
      {
        "role": "Fiordiligi",
        "work": "Così fan tutte",
        "note": {
          "en": "role debut",
          "sv": "rolldebut",
          "de": "Rollendebüt",
          "fr": "prise de rôle"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Sophie",
        "work": "Werther",
        "venue": "Oper Frankfurt"
      },
      {
        "role": {
          "en": "Young Woman",
          "sv": "Ung kvinna",
          "de": "Mädchen",
          "fr": "Jeune fille"
        },
        "work": {
          "en": "Blood Wedding",
          "sv": "Blodsbröllop",
          "de": "Bluthochzeit",
          "fr": "Noces de sang"
        },
        "note": {
          "en": "premiere",
          "sv": "premiär",
          "de": "Premiere",
          "fr": "création"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": {
          "en": "Pipetta & Duchess",
          "sv": "Pipetta & hertiginnan",
          "de": "Pipetta & Herzogin",
          "fr": "Pipetta & la Duchesse"
        },
        "work": {
          "en": "The Bandits",
          "sv": "Banditerna",
          "de": "Die Banditen",
          "fr": "Les Brigands"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Anna",
        "work": "Blühen",
        "venue": "Oper Frankfurt"
      },
      {
        "html": {
          "en": "Debut recording: Traetta's <em>Ifigenia in Tauride</em>, Aparté",
          "sv": "Debutskiva: Traettas <em>Ifigenia in Tauride</em>, Aparté",
          "de": "Debütaufnahme: Traettas <em>Ifigenia in Tauride</em>, Aparté",
          "fr": "Premier enregistrement : <em>Ifigenia in Tauride</em> de Traetta, Aparté"
        }
      }
    ]
  },
  {
    "year": "2025",
    "entries": [
      {
        "role": "Camille",
        "work": "Louise",
        "venue": "Festival d’Aix-en-Provence"
      },
      {
        "role": "Dori",
        "work": "Ifigenia in Tauride",
        "venue": "Innsbrucker Festwochen"
      },
      {
        "role": {
          "en": "Priestess",
          "sv": "Prästinna",
          "de": "Priesterin",
          "fr": "Prêtresse"
        },
        "work": "Aida",
        "venue": "Birgit Nilsson Festival, Båstad"
      },
      {
        "text": {
          "en": "Orchestra debuts with the Swedish Radio Symphony Orchestra and the Gothenburg Symphony Orchestra",
          "sv": "Orkesterdebuter med Sveriges Radios symfoniorkester och Göteborgs Symfoniker",
          "de": "Orchesterdebüts beim Schwedischen Rundfunk-Sinfonieorchester und den Göteborger Symphonikern",
          "fr": "Débuts avec l'Orchestre symphonique de la Radio suédoise et l'Orchestre symphonique de Göteborg"
        }
      },
      {
        "text": {
          "en": "Birgit Nilsson Stipendium",
          "sv": "Birgit Nilsson-stipendiet",
          "de": "Birgit-Nilsson-Stipendium",
          "fr": "Birgit Nilsson Stipendium"
        },
        "award": true
      },
      {
        "text": {
          "en": "Marianne & Sigvard Bernadotte Art Fund",
          "sv": "Marianne & Sigvard Bernadottes konstnärsfond",
          "de": "Marianne & Sigvard Bernadotte Art Fund",
          "fr": "Marianne & Sigvard Bernadotte Art Fund"
        },
        "award": true
      }
    ]
  },
  {
    "year": "2024/25",
    "entries": [
      {
        "role": "Aljeja",
        "work": {
          "en": "From the House of the Dead",
          "sv": "Från de dödas hus",
          "de": "Aus einem Totenhaus",
          "fr": "De la maison des morts"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": {
          "en": "Lady-in-Waiting",
          "sv": "Kammarfrun",
          "de": "Kammerfrau",
          "fr": "Suivante"
        },
        "work": "Macbeth",
        "note": {
          "en": "premiere",
          "sv": "premiär",
          "de": "Premiere",
          "fr": "création"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Barbarina",
        "work": "Le nozze di Figaro",
        "venue": "Oper Frankfurt"
      }
    ]
  },
  {
    "year": "2023/24",
    "entries": [
      {
        "text": {
          "en": "Joins the soloist ensemble of Oper Frankfurt",
          "sv": "Blir medlem av Oper Frankfurts solistensemble",
          "de": "Eintritt ins Solistenensemble der Oper Frankfurt",
          "fr": "Rejoint la troupe de solistes de l'Oper Frankfurt"
        }
      },
      {
        "role": "Silvia",
        "work": "Ascanio in Alba",
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Belisa",
        "work": "In seinem Garten liebt Don Perlimplín Belisa",
        "venue": "Oper Frankfurt"
      },
      {
        "role": {
          "en": "First Maid",
          "sv": "Första tjänarinnan",
          "de": "Erste Magd",
          "fr": "Première servante"
        },
        "work": "Daphne",
        "venue": "Oper Frankfurt"
      },
      {
        "role": {
          "en": "Young Shepherd",
          "sv": "Ung herde",
          "de": "Junger Hirt",
          "fr": "Jeune berger"
        },
        "work": "Tannhäuser",
        "note": {
          "en": "premiere",
          "sv": "premiär",
          "de": "Premiere",
          "fr": "création"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Clotilde",
        "work": "Norma",
        "note": {
          "en": "house debut, June 2024",
          "sv": "husdebut, juni 2024",
          "de": "Hausdebüt, Juni 2024",
          "fr": "débuts sur cette scène, juin 2024"
        },
        "venue": {
          "en": "Bayerische Staatsoper, Munich",
          "sv": "Bayerische Staatsoper, München",
          "de": "Bayerische Staatsoper, München",
          "fr": "Bayerische Staatsoper, Munich"
        }
      },
      {
        "text": {
          "en": "Master’s degree from the Universität Mozarteum Salzburg, with Barbara Bonney",
          "sv": "Masterexamen från Universität Mozarteum Salzburg, hos Barbara Bonney",
          "de": "Masterabschluss an der Universität Mozarteum Salzburg bei Barbara Bonney",
          "fr": "Master de l'Universität Mozarteum Salzburg, auprès de Barbara Bonney"
        }
      }
    ]
  },
  {
    "year": "2022/23",
    "entries": [
      {
        "role": "Pamina & Papagena",
        "work": "Die Zauberflöte",
        "venue": "Oper Frankfurt"
      },
      {
        "role": {
          "en": "Cock & Jay",
          "sv": "Tupp & nötskrika",
          "de": "Hahn & Eichelhäher",
          "fr": "Coq & Geai"
        },
        "work": {
          "en": "The Cunning Little Vixen",
          "sv": "Den listiga lilla räven",
          "de": "Das schlaue Füchslein",
          "fr": "La Petite Renarde rusée"
        },
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Isaura",
        "work": "Francesca da Rimini",
        "venue": "Oper Frankfurt & Tiroler Festspiele Erl"
      },
      {
        "role": "Nerina & Diana",
        "work": "La fedeltà premiata",
        "venue": "Haydn Festival, Brühl"
      },
      {
        "text": {
          "en": "Best Young Artist, Meistersinger von Nürnberg Competition",
          "sv": "Best Young Artist, Meistersinger von Nürnberg-tävlingen",
          "de": "Best Young Artist, Wettbewerb Die Meistersinger von Nürnberg",
          "fr": "Best Young Artist, concours Meistersinger von Nürnberg"
        },
        "award": true
      },
      {
        "text": {
          "en": "Region Kronoberg Culture Stipendium",
          "sv": "Region Kronobergs kulturstipendium",
          "de": "Kulturstipendium der Region Kronoberg",
          "fr": "Bourse culturelle de la Région Kronoberg"
        },
        "award": true
      }
    ]
  },
  {
    "year": "2021/22",
    "entries": [
      {
        "text": {
          "en": "Joins the Opera Studio of Oper Frankfurt",
          "sv": "Antas till Oper Frankfurts operastudio",
          "de": "Aufnahme ins Opernstudio der Oper Frankfurt",
          "fr": "Entre à l'Opera Studio de l'Oper Frankfurt"
        }
      },
      {
        "role": "Clotilde",
        "work": "Norma",
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Frasquita",
        "work": "Carmen",
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Suor Osmina",
        "work": "Suor Angelica",
        "venue": "Oper Frankfurt"
      },
      {
        "role": {
          "en": "Second Woman",
          "sv": "Andra kvinnan",
          "de": "Zweite Frau",
          "fr": "Deuxième femme"
        },
        "work": "Dido and Aeneas",
        "venue": "Oper Frankfurt"
      },
      {
        "role": "Donna Anna",
        "work": "Don Giovanni",
        "note": {
          "en": "in concert",
          "sv": "konsertant",
          "de": "konzertant",
          "fr": "en concert"
        },
        "venue": "Alte Oper, Frankfurt"
      },
      {
        "text": {
          "en": "Third Prize and three special prizes, International Haydn Competition, Rohrau",
          "sv": "Tredje pris och tre specialpriser, Internationella Haydntävlingen i Rohrau",
          "de": "Dritter Preis und drei Sonderpreise, Internationaler Haydn-Gesangswettbewerb Rohrau",
          "fr": "Troisième prix et trois prix spéciaux, Concours international Haydn de Rohrau"
        },
        "award": true
      }
    ]
  },
  {
    "year": "2020",
    "entries": [
      {
        "text": {
          "en": "First Prize “Golden Victoria”, DEBUT International Singing Competition",
          "sv": "Första pris ”Golden Victoria”, DEBUT International Singing Competition",
          "de": "Erster Preis „Golden Victoria“, DEBUT International Singing Competition",
          "fr": "Premier prix « Golden Victoria », DEBUT International Singing Competition"
        },
        "award": true
      },
      {
        "text": {
          "en": "Beethoven Lieder Prize, Rheinsberg International Singing Competition",
          "sv": "Beethoven-liedpriset, internationella sångtävlingen i Rheinsberg",
          "de": "Beethoven-Liedpreis, Internationaler Gesangswettbewerb Rheinsberg",
          "fr": "Prix de lied Beethoven, Concours international de chant de Rheinsberg"
        },
        "award": true
      }
    ]
  },
  {
    "year": "2017–18",
    "entries": [
      {
        "html": {
          "en": "<em>Death and Juliet</em> by Daniel Nelson, with Malin Broman and Musica Vitae (2018)",
          "sv": "<em>Döden & Julia</em> av Daniel Nelson, med Malin Broman och Musica Vitae (2018)",
          "de": "<em>Death and Juliet</em> von Daniel Nelson, mit Malin Broman und Musica Vitae (2018)",
          "fr": "<em>Death and Juliet</em> de Daniel Nelson, avec Malin Broman et Musica Vitae (2018)"
        }
      },
      {
        "html": {
          "en": "<em>Sound the Trumpet</em>, baroque concert series with Musica Vitae (2017)",
          "sv": "<em>Sound the Trumpet</em>, barockkonsertserie med Musica Vitae (2017)",
          "de": "<em>Sound the Trumpet</em>, Barockkonzertreihe mit Musica Vitae (2017)",
          "fr": "<em>Sound the Trumpet</em>, série de concerts baroques avec Musica Vitae (2017)"
        }
      }
    ]
  }
];

const REP_OPERA = [
  {
    "role": {
      "en": "Title role",
      "sv": "Titelrollen",
      "de": "Titelpartie",
      "fr": "Rôle-titre"
    },
    "work": "Zaide",
    "meta": "Oper Frankfurt, 2026",
    "info": {
      "composer": "Wolfgang Amadeus Mozart",
      "conductor": "George Petrou",
      "director": "David Hermann",
      "withWho": "Michael Porter (Gomatz), Peter Marsh (Soliman), Aleksander Myrling (Allazim), Pete Thanapat (Osmin)",
      "note": {
        "en": "New production at the Bockenheimer Depot; premiere 30 September 2026",
        "sv": "Nyuppsättning på Bockenheimer Depot; premiär 30 september 2026",
        "de": "Neuproduktion im Bockenheimer Depot; Premiere am 30. September 2026",
        "fr": "Nouvelle production au Bockenheimer Depot ; création le 30 septembre 2026"
      }
    }
  },
  {
    "role": "Fiordiligi",
    "work": "Così fan tutte",
    "meta": {
      "en": "Oper Frankfurt, since 2026",
      "sv": "Oper Frankfurt, sedan 2026",
      "de": "Oper Frankfurt, seit 2026",
      "fr": "Oper Frankfurt, depuis 2026"
    },
    "info": {
      "composer": "Wolfgang Amadeus Mozart",
      "conductor": "Takeshi Moriuchi / Alden Gatt",
      "director": "Mariame Clément",
      "withWho": "Kelsey Lauritano, Karolina Makuła (Dorabella), Elizabeth Reiter, Bianca Tognocchi (Despina), Sebastian Geyer, Liviu Holender (Don Alfonso)",
      "note": {
        "en": "Role debut January 2026; the revival opens the 2026/27 season",
        "sv": "Rolldebut januari 2026; nypremiären öppnar säsongen 2026/27",
        "de": "Rollendebüt Januar 2026; die Wiederaufnahme eröffnet die Spielzeit 2026/27",
        "fr": "Prise de rôle en janvier 2026 ; la reprise ouvre la saison 2026/27"
      }
    }
  },
  {
    "role": "Gretel",
    "work": "Hänsel und Gretel",
    "meta": "Oper Frankfurt, 2026",
    "info": {
      "composer": "Engelbert Humperdinck",
      "conductor": "Alden Gatt / Thomas Guggeis",
      "director": "Keith Warner",
      "withWho": "Karolina Makuła, Bianca Andrew (Hänsel)"
    }
  },
  {
    "role": "Oberto",
    "work": "Alcina",
    "meta": "Oper Frankfurt, 2027",
    "info": {
      "composer": "Georg Friedrich Händel",
      "conductor": "Julia Jones",
      "director": "Johannes Erath",
      "withWho": "Monika Buczkowska-Ward (Alcina), Elmar Hauser (Ruggiero), Katharina Magiera (Bradamante)"
    }
  },
  {
    "role": "Camille",
    "work": "Louise",
    "meta": "Festival d’Aix-en-Provence, 2025",
    "info": {
      "composer": "Gustave Charpentier",
      "conductor": "Giacomo Sagripanti",
      "director": "Christof Loy",
      "withWho": {
        "en": "Elsa Dreisig (Louise), Adam Smith (Julien), Sophie Koch (the Mother), Nicolas Courjal (the Father)",
        "sv": "Elsa Dreisig (Louise), Adam Smith (Julien), Sophie Koch (modern), Nicolas Courjal (fadern)",
        "de": "Elsa Dreisig (Louise), Adam Smith (Julien), Sophie Koch (Mutter), Nicolas Courjal (Vater)",
        "fr": "Elsa Dreisig (Louise), Adam Smith (Julien), Sophie Koch (la Mère), Nicolas Courjal (le Père)"
      }
    }
  },
  {
    "role": "Dori",
    "work": "Ifigenia in Tauride",
    "meta": "Innsbrucker Festwochen, 2025",
    "info": {
      "composer": "Tommaso Traetta",
      "conductor": "Christophe Rousset, Les Talens Lyriques",
      "director": "Nicola Raab",
      "withWho": "Rocío Pérez (Ifigenia), Rafał Tomkiewicz (Oreste), Alasdair Kent (Toante)",
      "noteHtml": {
        "en": "Recorded by Aparté, 2026; see <a href=\"#media\">Music & Video</a>",
        "sv": "Inspelad av Aparté, 2026; se <a href=\"#media\">Musik & video</a>",
        "de": "Aufgenommen von Aparté, 2026; siehe <a href=\"#media\">Musik & Video</a>",
        "fr": "Enregistré par Aparté, 2026 ; voir <a href=\"#media\">Musique & vidéo</a>"
      }
    }
  },
  {
    "role": "Sophie",
    "work": "Werther",
    "meta": "Oper Frankfurt, 2026",
    "info": {
      "composer": "Jules Massenet",
      "conductor": "Felix Bender",
      "director": "Willy Decker",
      "withWho": "John Osborn (Werther), Bianca Andrew (Charlotte), Sebastian Geyer (Albert)"
    }
  },
  {
    "role": "Anna",
    "work": "Blühen",
    "meta": "Oper Frankfurt, 2025",
    "info": {
      "composer": "Vito Žuraj",
      "conductor": "Michael Wendeberg, Ensemble Modern",
      "director": "Brigitte Fassbaender",
      "withWho": "Bianca Andrew (Aurelia), Michael Porter (Ken)",
      "note": {
        "en": "Revival at the Bockenheimer Depot",
        "sv": "Nypremiär på Bockenheimer Depot",
        "de": "Wiederaufnahme im Bockenheimer Depot",
        "fr": "Reprise au Bockenheimer Depot"
      }
    }
  },
  {
    "role": {
      "en": "Young Woman",
      "sv": "Ung kvinna",
      "de": "Mädchen",
      "fr": "Jeune fille"
    },
    "work": {
      "en": "Blood Wedding",
      "sv": "Blodsbröllop",
      "de": "Bluthochzeit",
      "fr": "Noces de sang"
    },
    "meta": "Oper Frankfurt, 2026",
    "info": {
      "composer": "Wolfgang Fortner",
      "conductor": "Duncan Ward",
      "director": "Àlex Ollé",
      "withWho": {
        "en": "Magdalena Hinterdobler (the Bride), Claudia Mahnke (the Mother), Mikołaj Trąbka (Leonardo)",
        "sv": "Magdalena Hinterdobler (bruden), Claudia Mahnke (modern), Mikołaj Trąbka (Leonardo)",
        "de": "Magdalena Hinterdobler (Braut), Claudia Mahnke (Mutter), Mikołaj Trąbka (Leonardo)",
        "fr": "Magdalena Hinterdobler (la Mariée), Claudia Mahnke (la Mère), Mikołaj Trąbka (Leonardo)"
      },
      "note": {
        "en": "Premiere May 2026",
        "sv": "Premiär maj 2026",
        "de": "Premiere Mai 2026",
        "fr": "Création en mai 2026"
      }
    }
  },
  {
    "role": {
      "en": "Pipetta & Duchess",
      "sv": "Pipetta & hertiginnan",
      "de": "Pipetta & Herzogin",
      "fr": "Pipetta & la Duchesse"
    },
    "work": {
      "en": "The Bandits",
      "sv": "Banditerna",
      "de": "Die Banditen",
      "fr": "Les Brigands"
    },
    "meta": "Oper Frankfurt, 2025",
    "info": {
      "composer": "Jacques Offenbach",
      "conductor": "Karsten Januschke",
      "director": "Katharina Thoma",
      "withWho": "Elizabeth Reiter (Fiorella), Karolina Makuła (Fragoletto), Michael Porter (Falsacappa)"
    }
  },
  {
    "role": "Aljeja",
    "work": {
      "en": "From the House of the Dead",
      "sv": "Från de dödas hus",
      "de": "Aus einem Totenhaus",
      "fr": "De la maison des morts"
    },
    "meta": "Oper Frankfurt, 2025",
    "info": {
      "composer": "Leoš Janáček",
      "conductor": "Robert Jindra",
      "director": "David Hermann",
      "withWho": "Domen Križaj (Gorjančikov), AJ Glueckert (Skuratov), Michael Nagy (Šiškov)"
    }
  },
  {
    "role": {
      "en": "Lady-in-Waiting",
      "sv": "Kammarfrun",
      "de": "Kammerfrau",
      "fr": "Suivante"
    },
    "work": "Macbeth",
    "meta": "Oper Frankfurt, 2024",
    "info": {
      "composer": "Giuseppe Verdi",
      "conductor": "Thomas Guggeis",
      "director": "R.B. Schlather",
      "withWho": "Nicholas Brownlee (Macbeth), Kihwan Sim (Banquo)",
      "note": {
        "en": "New production, premiere December 2024",
        "sv": "Nyuppsättning, premiär december 2024",
        "de": "Neuproduktion, Premiere Dezember 2024",
        "fr": "Nouvelle production, création en décembre 2024"
      }
    }
  },
  {
    "role": "Barbarina",
    "work": "Le nozze di Figaro",
    "meta": {
      "en": "Oper Frankfurt, since 2024",
      "sv": "Oper Frankfurt, sedan 2024",
      "de": "Oper Frankfurt, seit 2024",
      "fr": "Oper Frankfurt, depuis 2024"
    },
    "info": {
      "composer": "Wolfgang Amadeus Mozart",
      "conductor": "Alden Gatt",
      "director": "Tilmann Köhler",
      "withWho": {
        "en": "Nombulelo Yende (the Countess), Mikołaj Trąbka (the Count)",
        "sv": "Nombulelo Yende (grevinnan), Mikołaj Trąbka (greven)",
        "de": "Nombulelo Yende (Gräfin), Mikołaj Trąbka (Graf)",
        "fr": "Nombulelo Yende (la Comtesse), Mikołaj Trąbka (le Comte)"
      }
    }
  },
  {
    "role": "Clotilde",
    "work": "Norma",
    "meta": "Bayerische Staatsoper, 2024",
    "info": {
      "composer": "Vincenzo Bellini",
      "conductor": "Gianluca Capuano",
      "director": "Jürgen Rose",
      "withWho": "Sonya Yoncheva (Norma), Tara Erraught (Adalgisa), Joseph Calleja (Pollione)",
      "note": {
        "en": "House debut, June 2024",
        "sv": "Husdebut, juni 2024",
        "de": "Hausdebüt, Juni 2024",
        "fr": "Débuts sur cette scène, juin 2024"
      }
    }
  },
  {
    "role": "Silvia",
    "work": "Ascanio in Alba",
    "meta": "Oper Frankfurt, 2023",
    "info": {
      "composer": "Wolfgang Amadeus Mozart",
      "conductor": "Alden Gatt",
      "director": "Nina Brazier",
      "withWho": "Cecelia Hall (Ascanio), Kateryna Kasper (Venere), Anna Nekhames (Fauno)",
      "note": {
        "en": "At the Bockenheimer Depot",
        "sv": "På Bockenheimer Depot",
        "de": "Im Bockenheimer Depot",
        "fr": "Au Bockenheimer Depot"
      }
    }
  },
  {
    "role": "Belisa",
    "work": "…liebt Don Perlimplín Belisa",
    "meta": "Oper Frankfurt, 2024",
    "info": {
      "composer": "Wolfgang Fortner",
      "conductor": "Takeshi Moriuchi",
      "director": "Dorothea Kirschbaum",
      "withWho": "Sebastian Geyer (Don Perlimplín), Karolina Makuła (Marcolfa)"
    }
  },
  {
    "role": {
      "en": "First Maid",
      "sv": "Första tjänarinnan",
      "de": "Erste Magd",
      "fr": "Première servante"
    },
    "work": "Daphne",
    "meta": "Oper Frankfurt, 2023",
    "info": {
      "composer": "Richard Strauss",
      "conductor": "Lothar Koenigs",
      "director": "Claus Guth",
      "withWho": "Maria Bengtsson (Daphne), Peter Marsh (Apollo)"
    }
  },
  {
    "role": {
      "en": "Young Shepherd",
      "sv": "Ung herde",
      "de": "Junger Hirt",
      "fr": "Jeune berger"
    },
    "work": "Tannhäuser",
    "meta": "Oper Frankfurt, 2024",
    "info": {
      "composer": "Richard Wagner",
      "conductor": "Thomas Guggeis",
      "director": "Matthew Wild",
      "withWho": "Marco Jentzsch (Tannhäuser), Christina Nilsson (Elisabeth), Domen Križaj (Wolfram)",
      "note": {
        "en": "New production, premiere April 2024",
        "sv": "Nyuppsättning, premiär april 2024",
        "de": "Neuproduktion, Premiere April 2024",
        "fr": "Nouvelle production, création en avril 2024"
      }
    }
  },
  {
    "role": "Pamina & Papagena",
    "work": "Die Zauberflöte",
    "meta": {
      "en": "Oper Frankfurt, since 2022",
      "sv": "Oper Frankfurt, sedan 2022",
      "de": "Oper Frankfurt, seit 2022",
      "fr": "Oper Frankfurt, depuis 2022"
    },
    "info": {
      "composer": "Wolfgang Amadeus Mozart",
      "director": "Ted Huffman",
      "withWho": "Michael Porter (Tamino), Danylo Matviienko (Papageno)"
    }
  },
  {
    "role": {
      "en": "Cock & Jay",
      "sv": "Tupp & nötskrika",
      "de": "Hahn & Eichelhäher",
      "fr": "Coq & Geai"
    },
    "work": {
      "en": "The Cunning Little Vixen",
      "sv": "Den listiga lilla räven",
      "de": "Das schlaue Füchslein",
      "fr": "La Petite Renarde rusée"
    },
    "meta": "Oper Frankfurt, 2023",
    "info": {
      "composer": "Leoš Janáček",
      "conductor": "Jonathan Stockhammer",
      "director": "Ute M. Engelhardt",
      "withWho": {
        "en": "Elizabeth Reiter (the Vixen)",
        "sv": "Elizabeth Reiter (räven)",
        "de": "Elizabeth Reiter (Füchsin)",
        "fr": "Elizabeth Reiter (la Renarde)"
      }
    }
  },
  {
    "role": "Isaura",
    "work": "Francesca da Rimini",
    "meta": "Tiroler Festspiele Erl & Oper Frankfurt, 2022/23",
    "info": {
      "composer": "Saverio Mercadante",
      "conductor": "Giuliano Carella (Erl) / Ramón Tebar (Frankfurt)",
      "director": "Hans Walter Richter",
      "withWho": {
        "en": "Jessica Pratt (Francesca, Frankfurt), Anna Nekhames (Francesca, Erl)",
        "sv": "Jessica Pratt (Francesca, Frankfurt), Anna Nekhames (Francesca, Erl)",
        "de": "Jessica Pratt (Francesca, Frankfurt), Anna Nekhames (Francesca, Erl)",
        "fr": "Jessica Pratt (Francesca, Francfort), Anna Nekhames (Francesca, Erl)"
      }
    }
  },
  {
    "role": "Nerina & Diana",
    "work": "La fedeltà premiata",
    "meta": "Haydn Festival, Brühl, 2022",
    "info": {
      "composer": "Joseph Haydn",
      "conductor": "Andreas Spering, Capella Augustina",
      "withWho": "Sophie Harmsen (Celia), Ylva Stenberg (Amaranta), Bruno Taddia (Perrucchetto)",
      "note": {
        "en": "Concert performances, also at the Tage Alter Musik Herne",
        "sv": "Konsertanta föreställningar, även vid Tage Alter Musik Herne",
        "de": "Konzertante Aufführungen, auch bei den Tagen Alter Musik Herne",
        "fr": "Versions de concert, également aux Tage Alter Musik de Herne"
      }
    }
  },
  {
    "role": "Frasquita",
    "work": "Carmen",
    "meta": "Oper Frankfurt, 2021",
    "info": {
      "composer": "Georges Bizet",
      "note": {
        "en": "Opera Studio years",
        "sv": "Operastudioåren",
        "de": "Opernstudio-Jahre",
        "fr": "Années d'Opera Studio"
      }
    }
  },
  {
    "role": "Suor Osmina",
    "work": "Suor Angelica",
    "meta": "Oper Frankfurt, 2021",
    "info": {
      "composer": "Giacomo Puccini",
      "note": {
        "en": "Opera Studio years",
        "sv": "Operastudioåren",
        "de": "Opernstudio-Jahre",
        "fr": "Années d'Opera Studio"
      }
    }
  },
  {
    "role": "Donna Anna",
    "work": "Don Giovanni",
    "meta": {
      "en": "in concert, Alte Oper, 2021",
      "sv": "konsertant, Alte Oper, 2021",
      "de": "konzertant, Alte Oper, 2021",
      "fr": "en concert, Alte Oper, 2021"
    },
    "info": {
      "composer": "Wolfgang Amadeus Mozart",
      "note": {
        "en": "Concert performance at the Alte Oper, Frankfurt",
        "sv": "Konsertant föreställning i Alte Oper, Frankfurt",
        "de": "Konzertante Aufführung in der Alten Oper Frankfurt",
        "fr": "Version de concert à l'Alte Oper de Francfort"
      }
    }
  }
];

const REP_CONCERT = [
  {
    "work": {
      "en": "Death and Juliet",
      "sv": "Döden & Julia",
      "de": "Death and Juliet",
      "fr": "Death and Juliet"
    },
    "meta": {
      "en": "Daniel Nelson, 2018",
      "sv": "Daniel Nelson, 2018",
      "de": "Daniel Nelson, 2018",
      "fr": "Daniel Nelson, 2018"
    },
    "info": {
      "composer": "Daniel Nelson",
      "withWho": {
        "en": "Malin Broman (violin) and Musica Vitae",
        "sv": "Malin Broman (violin) och Musica Vitae",
        "de": "Malin Broman (Violine) und Musica Vitae",
        "fr": "Malin Broman (violon) et Musica Vitae"
      },
      "noteHtml": {
        "en": "Concert work, 2018, to a libretto by Tuva-Lisa Rangström. Watch it under <a href=\"#media\">Music & Video</a>",
        "sv": "Konsertverk från 2018, till libretto av Tuva-Lisa Rangström. Se den under <a href=\"#media\">Musik & video</a>",
        "de": "Konzertwerk, 2018, auf ein Libretto von Tuva-Lisa Rangström. Zu sehen unter <a href=\"#media\">Musik & Video</a>",
        "fr": "Œuvre de concert, 2018, sur un livret de Tuva-Lisa Rangström. À voir sous <a href=\"#media\">Musique & vidéo</a>"
      }
    }
  },
  {
    "work": "Förklädd Gud",
    "meta": {
      "en": "Lars-Erik Larsson (God in Disguise)",
      "sv": "Lars-Erik Larsson",
      "de": "Lars-Erik Larsson (Der verkleidete Gott)",
      "fr": "Lars-Erik Larsson (Dieu déguisé)"
    },
    "info": {
      "composer": "Lars-Erik Larsson",
      "note": {
        "en": "Lyric suite to Hjalmar Gullberg's poem",
        "sv": "Lyrisk svit till Hjalmar Gullbergs dikt",
        "de": "Lyrische Suite nach Hjalmar Gullbergs Gedicht",
        "fr": "Suite lyrique sur le poème de Hjalmar Gullberg"
      }
    }
  },
  {
    "work": "Ein deutsches Requiem",
    "meta": "Brahms",
    "info": {
      "composer": "Johannes Brahms"
    }
  },
  {
    "work": {
      "en": "Die Schöpfung",
      "sv": "Skapelsen",
      "de": "Die Schöpfung",
      "fr": "La Création"
    },
    "meta": "Haydn",
    "info": {
      "composer": "Joseph Haydn"
    }
  },
  {
    "work": {
      "en": "Die Jahreszeiten",
      "sv": "Årstiderna",
      "de": "Die Jahreszeiten",
      "fr": "Les Saisons"
    },
    "meta": "Haydn",
    "info": {
      "composer": "Joseph Haydn"
    }
  },
  {
    "work": {
      "en": "St Matthew Passion",
      "sv": "Matteuspassionen",
      "de": "Matthäus-Passion",
      "fr": "Passion selon saint Matthieu"
    },
    "meta": "Bach",
    "info": {
      "composer": "Johann Sebastian Bach"
    }
  },
  {
    "work": "Stabat Mater",
    "meta": "Pergolesi",
    "info": {
      "composer": "Giovanni Battista Pergolesi"
    }
  }
];

const SEASON = [
  {
    "dates": {
      "en": "23 Aug – 21 Jan",
      "sv": "23 aug – 21 jan",
      "de": "23. Aug. – 21. Jan.",
      "fr": "23 août – 21 janv."
    },
    "work": "Così fan tutte",
    "role": "Fiordiligi",
    "sub": {
      "en": "Mozart, revival",
      "sv": "Mozart, nypremiär",
      "de": "Mozart, Wiederaufnahme",
      "fr": "Mozart, reprise"
    },
    "of": "cosi"
  },
  {
    "dates": {
      "en": "30 Sep – 18 Oct",
      "sv": "30 sep – 18 okt",
      "de": "30. Sep. – 18. Okt.",
      "fr": "30 sept. – 18 oct."
    },
    "work": "Zaide",
    "role": {
      "en": "Title role",
      "sv": "Titelrollen",
      "de": "Titelpartie",
      "fr": "Rôle-titre"
    },
    "sub": "Mozart, Bockenheimer Depot",
    "premiere": true,
    "venue": "Bockenheimer Depot",
    "of": "zaide"
  },
  {
    "dates": {
      "en": "13 Nov – 26 Dec",
      "sv": "13 nov – 26 dec",
      "de": "13. Nov. – 26. Dez.",
      "fr": "13 nov. – 26 déc."
    },
    "work": "Hänsel und Gretel",
    "role": "Gretel",
    "sub": {
      "en": "Humperdinck, revival",
      "sv": "Humperdinck, nypremiär",
      "de": "Humperdinck, Wiederaufnahme",
      "fr": "Humperdinck, reprise"
    },
    "of": "haensel"
  },
  {
    "dates": {
      "en": "20 Feb – 27 Mar",
      "sv": "20 feb – 27 mars",
      "de": "20. Feb. – 27. März",
      "fr": "20 févr. – 27 mars"
    },
    "work": "Alcina",
    "role": "Oberto",
    "sub": {
      "en": "Händel, conducted by Julia Jones",
      "sv": "Händel, dirigent Julia Jones",
      "de": "Händel, Leitung Julia Jones",
      "fr": "Händel, direction Julia Jones"
    },
    "of": "alcina"
  }
];

const OF = {
  cosi: {
    en: "https://www.oper-frankfurt.de/en/season-calendar/cosi-fan-tutte_4/",
    de: "https://www.oper-frankfurt.de/de/spielplan/cosi-fan-tutte_4/"
  },
  zaide: {
    en: "https://www.oper-frankfurt.de/en/season-calendar/zaide/",
    de: "https://www.oper-frankfurt.de/de/spielplan/zaide/"
  },
  haensel: {
    en: "https://www.oper-frankfurt.de/en/season-calendar/haensel-und-gretel_5/",
    de: "https://www.oper-frankfurt.de/de/spielplan/haensel-und-gretel_5/"
  },
  alcina: {
    en: "https://www.oper-frankfurt.de/en/season-calendar/alcina_2/",
    de: "https://www.oper-frankfurt.de/de/spielplan/alcina_2/"
  },
  profile: {
    en: "https://www.oper-frankfurt.de/en/ensemble/opera-studio/?detail=1144",
    de: "https://www.oper-frankfurt.de/de/ensemble-gaeste-teams/opernstudio/?detail=1144"
  }
};

const PRESS_PHOTOS = [
  { file: "img/anna.jpg", thumb: "img/anna-480.webp", name: "Karolina-Bengtsson-Anna-Bluehen.jpg", credit: "credit.anna", alt: "gallery.annaAlt", size: "1179 × 779" },
  { file: "img/belisa.jpg", thumb: "img/belisa-480.webp", name: "Karolina-Bengtsson-Belisa.jpg", credit: "credit.belisa", alt: "gallery.belisaAlt", size: "1179 × 834" },
  { file: "img/hero.jpg", thumb: "img/hero-480.webp", name: "Karolina-Bengtsson-portrait.jpg", credit: "credit.portrait", alt: "opening.portraitAlt", size: "927 × 1159" }
];

function ofHref(key, lang) {
  var urls = OF[key];
  if (!urls) return "";
  return lang === "de" ? urls.de : urls.en;
}

function lookup(key) {
  var parts = key.split(".");
  var cur = COPY;
  for (var i = 0; i < parts.length; i++) {
    if (cur == null) return;
    cur = cur[parts[i]];
  }
  return cur;
}

function decorateLinks(root, lang) {
  var tipText = M(COPY.newtab, lang);
  root.querySelectorAll("a[href]").forEach(function (a) {
    var href = a.getAttribute("href") || "";
    if (href.charAt(0) === "#" || href.indexOf("mailto:") === 0 || href.indexOf("tel:") === 0) return;
    if (a.hasAttribute("download") || a.hasAttribute("data-press-file")) return;
    a.target = "_blank";
    a.rel = "noreferrer";
    var tip = a.querySelector(".visually-hidden");
    if (!tip) {
      tip = document.createElement("span");
      tip.className = "visually-hidden";
      a.appendChild(tip);
    }
    tip.textContent = tipText;
  });
}

function detectLang() {
  try {
    var q = new URLSearchParams(location.search).get("lang");
    if (LANGS.indexOf(q) !== -1) return q;
  } catch (e) {}
  try {
    var stored = window.localStorage.getItem(STORE);
    if (LANGS.indexOf(stored) !== -1) return stored;
  } catch (e) {}
  var nav = (navigator.language || "").slice(0, 2).toLowerCase();
  return LANGS.indexOf(nav) !== -1 ? nav : "sv";
}

function syncLangUrl(lang, force) {
  try {
    var url = new URL(location.href);
    var current = url.searchParams.get("lang");
    if (!force && !current) return;
    if (current === lang) return;
    url.searchParams.set("lang", lang);
    history.replaceState(null, "", url.pathname + url.search + url.hash);
  } catch (e) {}
}

function applyChrome(lang) {
  document.documentElement.lang = lang;
  document.title = M(COPY.title, lang);
  var desc = M(COPY.desc, lang);
  var meta = document.querySelector("meta[name=\"description\"]");
  if (meta) meta.setAttribute("content", desc);
  var ogt = document.querySelector("meta[property=\"og:title\"]");
  if (ogt) ogt.setAttribute("content", M(COPY.title, lang));
  var twt = document.querySelector("meta[name=\"twitter:title\"]");
  if (twt) twt.setAttribute("content", M(COPY.title, lang));
  var ogd = document.querySelector("meta[property=\"og:description\"]");
  if (ogd) ogd.setAttribute("content", desc);
  var twd = document.querySelector("meta[name=\"twitter:description\"]");
  if (twd) twd.setAttribute("content", desc);
  var localeMap = { en: "en_US", sv: "sv_SE", de: "de_DE", fr: "fr_FR" };
  var locales = ["en_US", "sv_SE", "de_DE", "fr_FR"];
  var currentLocale = localeMap[lang] || "en_US";
  var ogl = document.querySelector("meta[property=\"og:locale\"]");
  if (ogl) ogl.setAttribute("content", currentLocale);
  document.querySelectorAll("meta[property=\"og:locale:alternate\"]").forEach(function (el) {
    el.parentNode.removeChild(el);
  });
  locales.forEach(function (code) {
    if (code === currentLocale) return;
    var alt = document.createElement("meta");
    alt.setAttribute("property", "og:locale:alternate");
    alt.setAttribute("content", code);
    if (ogl && ogl.parentNode) ogl.parentNode.insertBefore(alt, ogl.nextSibling);
  });

  document.querySelectorAll("[data-i18n]").forEach(function (el) {
    var val = lookup(el.getAttribute("data-i18n"));
    if (val != null) el.textContent = M(val, lang);
  });
  document.querySelectorAll("[data-i18n-html]").forEach(function (el) {
    var val = lookup(el.getAttribute("data-i18n-html"));
    if (val != null) el.innerHTML = M(val, lang);
  });
  document.querySelectorAll("[data-i18n-alt]").forEach(function (el) {
    var val = lookup(el.getAttribute("data-i18n-alt"));
    if (val != null) el.setAttribute("alt", M(val, lang));
  });
  document.querySelectorAll("[data-i18n-aria]").forEach(function (el) {
    var val = lookup(el.getAttribute("data-i18n-aria"));
    if (val != null) el.setAttribute("aria-label", M(val, lang));
  });

  document.querySelectorAll(".lang").forEach(function (group) {
    group.setAttribute("aria-label", M(COPY.langLabel, lang));
  });
  document.querySelectorAll(".lang button").forEach(function (btn) {
    btn.setAttribute("aria-pressed", btn.getAttribute("data-lang") === lang ? "true" : "false");
  });

  var nav = document.getElementById("site-nav");
  if (nav) nav.setAttribute("aria-label", M(COPY.navLabel, lang));

  var menu = document.getElementById("menu-btn");
  if (menu) {
    var open = menu.getAttribute("aria-expanded") === "true";
    menu.textContent = M(open ? COPY.menuClose : COPY.menu, lang);
  }
}

function renderNews(lang) {
  var host = document.getElementById("news-list");
  if (!host) return;
  var items = [NEWS[0], NEWS[1], NEWS[4]];
  var lead = items[0];
  var rest = items.slice(1);
  var display = lead.display ? "<p class=\"news-display\">" + M(lead.display, lang) + "</p>" : "";
  var splash = "<article class=\"news-lead\">" + display +
    "<p class=\"news-date\">" + M(lead.date, lang) + "</p>" +
    "<h3>" + M(lead.headline, lang) + "</h3>" +
    "<p class=\"body\">" + M(lead.body, lang) + "</p></article>";
  var briefs = "<details class=\"full-fold\"><summary>" + M(COPY.news.more, lang) + "</summary>" +
    "<div class=\"news-rest\">" + rest.map(function (item) {
    return "<article class=\"news-item\"><p class=\"news-date\">" + M(item.date, lang) +
      "</p><h3>" + M(item.headline, lang) + "</h3><p class=\"body\">" +
      M(item.body, lang) + "</p></article>";
  }).join("") + "</div></details>";
  host.innerHTML = splash + briefs;
  decorateLinks(host, lang);
  rewriteOperFrankfurtLinks(lang);
}

function entryHtml(entry, lang, prizeWord) {
  if (entry.award) {
    return "<li><span><span class=\"prize\">" + prizeWord + "</span> " + M(entry.text, lang) + "</span></li>";
  }
  if (entry.html) return "<li><span>" + M(entry.html, lang) + "</span></li>";
  if (entry.text) return "<li><span>" + M(entry.text, lang) + "</span></li>";
  var note = entry.note ? " <span class=\"hint\">" + M(entry.note, lang) + "</span>" : "";
  var venue = entry.venue ? "<span class=\"venue\">" + M(entry.venue, lang) + "</span>" : "";
  return "<li><span>" + M(entry.role, lang) + ", <em>" + M(entry.work, lang) + "</em>" + note + "</span>" + venue + "</li>";
}

function yearBlockHtml(block, lang, prizeWord) {
  var rows = block.entries.map(function (entry) {
    return entryHtml(entry, lang, prizeWord);
  }).join("");
  return "<div class=\"year-block\"><p class=\"year\">" + block.year + "</p><ul class=\"year-entries\">" + rows + "</ul></div>";
}

function isSelectedEntry(block, entry) {
  var year = block.year;
  if (year === "2026/27") return true;
  if (year === "2025/26") {
    if (M(entry.work, "en") === "Così fan tutte") return true;
    if (entry.html && /Ifigenia/.test(M(entry.html, "en"))) return true;
    return false;
  }
  if (year === "2025") {
    if (M(entry.role, "en") === "Camille") return true;
    if (M(entry.role, "en") === "Dori") return true;
    if (entry.award && /Birgit Nilsson/.test(M(entry.text, "en"))) return true;
    return false;
  }
  if (year === "2023/24") {
    return !!(entry.text && /soloist ensemble/.test(M(entry.text, "en")));
  }
  return false;
}

function renderChronology(lang) {
  var host = document.getElementById("chrono-list");
  var fullHost = document.getElementById("chrono-full");
  if (!host) return;
  var prizeWord = M(COPY.chrono.prize, lang);
  host.innerHTML = CHRONOLOGY.map(function (block) {
    var entries = block.entries.filter(function (entry) { return isSelectedEntry(block, entry); });
    if (!entries.length) return "";
    return yearBlockHtml({ year: block.year, entries: entries }, lang, prizeWord);
  }).join("");
  if (fullHost) {
    fullHost.innerHTML = CHRONOLOGY.map(function (block) {
      return yearBlockHtml(block, lang, prizeWord);
    }).join("");
  }
  decorateLinks(host, lang);
  if (fullHost) decorateLinks(fullHost, lang);
  rewriteOperFrankfurtLinks(lang);
}

function repRow(label, value) {
  if (!value) return "";
  return "<div class=\"rep-row\"><span class=\"k\">" + label + "</span><span>" + value + "</span></div>";
}

function workKey(item) {
  if (item.work == null) return "";
  return typeof item.work === "string" ? item.work : (item.work.en || "");
}

var SELECTED_OPERA = ["Zaide", "Così fan tutte", "Louise", "Ifigenia in Tauride", "Blühen", "Ascanio in Alba"];
var SELECTED_CONCERT = ["Death and Juliet", "Ein deutsches Requiem", "Die Schöpfung", "Die Jahreszeiten"];

function renderRepItem(item, lang, concert) {
  var work = M(item.work, lang);
  var who = concert
    ? "<span class=\"work\">" + work + "</span>"
    : "<span class=\"who\">" + M(item.role, lang) + " <span class=\"work\">" + work + "</span></span>";
  var info = item.info || {};
  var note = info.noteHtml ? M(info.noteHtml, lang) : M(info.note, lang);
  var rows = [
    repRow(M(COPY.rep.composer, lang), info.composer),
    info.conductor ? repRow(M(COPY.rep.conductor, lang), info.conductor) : "",
    info.director ? repRow(M(COPY.rep.director, lang), info.director) : "",
    info.withWho ? repRow(M(COPY.rep.withWho, lang), M(info.withWho, lang)) : "",
    note ? repRow(M(COPY.rep.about, lang), note) : ""
  ].join("");
  return "<details class=\"rep\"><summary>" + who + "<span class=\"chevron\" aria-hidden=\"true\"></span></summary>" +
    "<div class=\"rep-body\"><p class=\"meta rep-meta\">" + M(item.meta, lang) + "</p>" + rows + "</div></details>";
}

function renderRepertoire(lang) {
  var operaHost = document.getElementById("rep-opera");
  var concertHost = document.getElementById("rep-concert");
  if (!operaHost || !concertHost) return;
  var selectedOp = REP_OPERA.filter(function (item) { return SELECTED_OPERA.indexOf(workKey(item)) !== -1; });
  var selectedCo = REP_CONCERT.filter(function (item) { return SELECTED_CONCERT.indexOf(workKey(item)) !== -1; });
  operaHost.innerHTML = selectedOp.map(function (item) { return renderRepItem(item, lang, false); }).join("");
  concertHost.innerHTML = selectedCo.map(function (item) { return renderRepItem(item, lang, true); }).join("");
  var operaFull = document.getElementById("rep-opera-full");
  var concertFull = document.getElementById("rep-concert-full");
  if (operaFull) operaFull.innerHTML = REP_OPERA.map(function (item) { return renderRepItem(item, lang, false); }).join("");
  if (concertFull) concertFull.innerHTML = REP_CONCERT.map(function (item) { return renderRepItem(item, lang, true); }).join("");
  decorateLinks(operaHost, lang);
  decorateLinks(concertHost, lang);
  if (operaFull) decorateLinks(operaFull, lang);
  if (concertFull) decorateLinks(concertFull, lang);
  rewriteOperFrankfurtLinks(lang);
}

function renderSeason(lang) {
  var host = document.getElementById("season-list");
  if (!host) return;
  var tickets = M(COPY.season.tickets, lang);
  var defaultVenue = M(COPY.season.venue, lang);
  var rows = SEASON.map(function (item) {
    var flag = item.premiere ? "<span class=\"season-flag\">" + M(COPY.season.flag, lang) + "</span>" : "";
    var sub = item.sub ? "<p class=\"season-row-sub\">" + M(item.sub, lang) + "</p>" : "";
    var venue = item.venue ? M(item.venue, lang) : defaultVenue;
    var href = ofHref(item.of, lang);
    return "<article class=\"season-row\">" +
      "<p class=\"season-row-dates\">" + M(item.dates, lang) + "</p>" +
      "<div class=\"season-row-main\">" +
        "<h3 class=\"season-row-work\"><em>" + item.work + "</em>" + flag + "</h3>" +
        "<p class=\"season-row-role\">" + M(item.role, lang) + "</p>" +
        sub +
      "</div>" +
      "<p class=\"season-row-venue\">" + venue + "</p>" +
      "<a class=\"season-row-ticket\" data-of=\"" + item.of + "\" href=\"" + href + "\">" + tickets + " <span aria-hidden=\"true\">→</span></a>" +
    "</article>";
  }).join("");
  host.innerHTML = "<div class=\"season-list\">" + rows + "</div>";
  decorateLinks(host, lang);
  rewriteOperFrankfurtLinks(lang);
}

function rewriteOperFrankfurtLinks(lang) {
  document.querySelectorAll("[data-of]").forEach(function (a) {
    var href = ofHref(a.getAttribute("data-of"), lang);
    if (href) a.setAttribute("href", href);
  });
}

function filenameForPress(kind, lang) {
  var base = {
    short: {
      en: "Karolina-Bengtsson-short-biography-EN.txt",
      sv: "Karolina-Bengtsson-kort-biografi-SV.txt",
      de: "Karolina-Bengtsson-Kurzbiographie-DE.txt",
      fr: "Karolina-Bengtsson-biographie-courte-FR.txt"
    },
    long: {
      en: "Karolina-Bengtsson-biography-EN.txt",
      sv: "Karolina-Bengtsson-biografi-SV.txt",
      de: "Karolina-Bengtsson-Biographie-DE.txt",
      fr: "Karolina-Bengtsson-biographie-FR.txt"
    }
  };
  return (base[kind] && base[kind][lang]) || ("Karolina-Bengtsson-" + kind + ".txt");
}

function downloadBlob(filename, blob) {
  var url = URL.createObjectURL(blob);
  var a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
}

function downloadTextFile(filename, text) {
  downloadBlob(filename, new Blob([text], { type: "text/plain;charset=utf-8" }));
}

function downloadHref(url, filename) {
  fetch(url).then(function (res) {
    if (!res.ok) throw new Error("download failed");
    return res.blob();
  }).then(function (blob) {
    downloadBlob(filename, blob);
  }).catch(function () {
    var a = document.createElement("a");
    a.href = url;
    a.download = filename;
    a.rel = "noopener";
    document.body.appendChild(a);
    a.click();
    a.remove();
  });
}

function renderPress(lang) {
  var shortEl = document.getElementById("press-short");
  var longEl = document.getElementById("press-long");
  if (shortEl) shortEl.innerHTML = "<p>" + M(COPY.press.short, lang) + "</p>";
  if (longEl) {
    longEl.innerHTML = M(COPY.press.long, lang).split(/\n\n+/).map(function (p) {
      return "<p>" + p + "</p>";
    }).join("");
  }
  var host = document.getElementById("press-photos");
  if (host) {
    var dl = M(COPY.press.download, lang);
    host.innerHTML = PRESS_PHOTOS.map(function (photo) {
      return "<figure class=\"press-shot\">" +
        "<img src=\"" + photo.file + "\" alt=\"" + M(lookup(photo.alt), lang) + "\" loading=\"lazy\" decoding=\"async\">" +
        "<figcaption>" +
          "<span>" + M(lookup(photo.credit), lang) + "</span>" +
          "<span>" + photo.size + " px</span>" +
          "<a href=\"" + photo.file + "\" download=\"" + photo.name + "\" data-press-file=\"" + photo.file + "\">" + dl + "</a>" +
        "</figcaption>" +
      "</figure>";
    }).join("");
  }
  var cv = document.getElementById("press-cv-link");
  if (cv) cv.setAttribute("href", "press/cv.html?lang=" + lang);
  var pdf = document.getElementById("press-cv-pdf");
  if (pdf) {
    var pdfName = "Karolina-Bengtsson-CV-" + lang + ".pdf";
    pdf.setAttribute("href", "press/" + pdfName);
    pdf.setAttribute("download", pdfName);
  }
}

function setupPressDownloads() {
  document.querySelectorAll("[data-press-download]").forEach(function (btn) {
    btn.addEventListener("click", function () {
      var kind = btn.getAttribute("data-press-download");
      var text = M(kind === "long" ? COPY.press.long : COPY.press.short, currentLang);
      downloadTextFile(filenameForPress(kind, currentLang), text);
    });
  });
  var photos = document.getElementById("press-photos");
  if (photos) {
    photos.addEventListener("click", function (event) {
      var a = event.target.closest("a[data-press-file]");
      if (!a) return;
      event.preventDefault();
      downloadHref(a.getAttribute("data-press-file"), a.getAttribute("download"));
    });
  }
}

function prefersReducedMotion() {
  return window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
}

var langFadeTimer = 0;

function applyLang(lang, opts) {
  var restoreScroll = opts && opts.restoreScroll;
  var y = restoreScroll ? window.scrollY : 0;
  currentLang = lang;
  try { window.localStorage.setItem(STORE, lang); } catch (e) {}
  syncLangUrl(lang, opts && opts.syncUrl);
  applyChrome(lang);
  renderNews(lang);
  renderChronology(lang);
  renderRepertoire(lang);
  renderSeason(lang);
  renderPress(lang);
  decorateLinks(document, lang);
  rewriteOperFrankfurtLinks(lang);
  if (restoreScroll) window.scrollTo(0, y);
}

function setLang(lang, opts) {
  var changing = lang !== currentLang;
  var animate = opts && opts.animate && changing;
  var main = document.getElementById("main");
  if (langFadeTimer) {
    window.clearTimeout(langFadeTimer);
    langFadeTimer = 0;
  }
  if (animate && main && !prefersReducedMotion()) {
    main.classList.add("is-lang-fading");
    langFadeTimer = window.setTimeout(function () {
      langFadeTimer = 0;
      applyLang(lang, { restoreScroll: true, syncUrl: true });
      requestAnimationFrame(function () {
        main.classList.remove("is-lang-fading");
      });
    }, 140);
    return;
  }
  if (main) main.classList.remove("is-lang-fading");
  applyLang(lang, { restoreScroll: changing, syncUrl: changing });
}

function isMobileNav() {
  return window.innerWidth <= 959;
}

function setMenuOpen(open) {
  var btn = document.getElementById("menu-btn");
  var nav = document.getElementById("site-nav");
  var header = document.querySelector(".site-header");
  if (!btn || !nav) return;
  nav.classList.toggle("is-open", open);
  if (header) header.classList.toggle("is-menu-open", open);
  btn.setAttribute("aria-expanded", open ? "true" : "false");
  btn.textContent = M(open ? COPY.menuClose : COPY.menu, currentLang);
  syncMenuInert();
}

function syncMenuInert() {
  var btn = document.getElementById("menu-btn");
  var nav = document.getElementById("site-nav");
  if (!nav) return;
  var open = btn && btn.getAttribute("aria-expanded") === "true";
  if (isMobileNav() && !open) {
    nav.setAttribute("inert", "");
    nav.setAttribute("aria-hidden", "true");
  } else {
    nav.removeAttribute("inert");
    nav.removeAttribute("aria-hidden");
  }
}

function setupMenu() {
  var btn = document.getElementById("menu-btn");
  var nav = document.getElementById("site-nav");
  if (!btn || !nav) return;
  setMenuOpen(false);
  btn.addEventListener("click", function () {
    setMenuOpen(!(nav.classList.contains("is-open")));
  });
  nav.querySelectorAll("a").forEach(function (a) {
    a.addEventListener("click", function () { setMenuOpen(false); });
  });
  window.addEventListener("resize", function () {
    if (!isMobileNav()) setMenuOpen(false);
    else syncMenuInert();
  });
}

function setupSectionWatch() {
  var nav = document.getElementById("site-nav");
  if (!nav || !("IntersectionObserver" in window)) return;
  var links = nav.querySelectorAll('a[href^="#"]');
  var map = {};
  links.forEach(function (a) {
    var id = (a.getAttribute("href") || "").slice(1);
    if (id && document.getElementById(id)) map[id] = a;
  });
  var ids = Object.keys(map);
  if (!ids.length) return;
  var visible = [];
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      var id = entry.target.id;
      var idx = visible.indexOf(id);
      if (entry.isIntersecting) {
        if (idx === -1) visible.push(id);
      } else if (idx !== -1) {
        visible.splice(idx, 1);
      }
    });
    links.forEach(function (a) { a.removeAttribute("aria-current"); });
    var current = visible[0];
    ids.forEach(function (id) {
      if (visible.indexOf(id) !== -1) current = id;
    });
    if (current && map[current]) map[current].setAttribute("aria-current", "page");
  }, { rootMargin: "-22% 0px -62% 0px", threshold: 0.01 });
  ids.forEach(function (id) { io.observe(document.getElementById(id)); });
}

function loadEmbed(btn) {
  if (!btn || btn.getAttribute("data-loaded") === "1") return;
  var kind = btn.getAttribute("data-embed");
  var src = btn.getAttribute("data-src");
  if (!src) return;
  var iframe = document.createElement("iframe");
  iframe.src = src;
  iframe.title = btn.getAttribute("data-title") || "";
  iframe.setAttribute("referrerpolicy", "strict-origin-when-cross-origin");
  iframe.setAttribute("loading", "lazy");
  if (kind === "spotify") {
    iframe.height = "352";
    iframe.setAttribute("allow", "clipboard-write; encrypted-media; fullscreen; picture-in-picture");
  } else {
    iframe.setAttribute("allow", "accelerometer; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share");
    iframe.setAttribute("allowfullscreen", "");
  }
  btn.setAttribute("data-loaded", "1");
  var slot = btn.getAttribute("data-target");
  var host = (slot && document.getElementById(slot)) || btn.parentNode;
  if (!host) return;
  host.hidden = false;
  host.classList.add("is-playing");
  if (host === btn.parentNode) {
    host.replaceChild(iframe, btn);
  } else {
    host.innerHTML = "";
    host.appendChild(iframe);
    btn.setAttribute("hidden", "");
  }
}

function setupMedia() {
  document.querySelectorAll("[data-embed]").forEach(function (btn) {
    btn.addEventListener("click", function () { loadEmbed(btn); });
  });
}

function setupToTop() {
  document.querySelectorAll('a[href="#top"]').forEach(function (a) {
    a.addEventListener("click", function (event) {
      event.preventDefault();
      var reduce = prefersReducedMotion();
      if (reduce) window.scrollTo(0, 0);
      else window.scrollTo({ top: 0, behavior: "smooth" });
      var dest = document.getElementById("top");
      if (dest && dest.focus) {
        try { dest.focus({ preventScroll: true }); } catch (e) { dest.focus(); }
      }
    });
  });
}

function setupReveal() {
  var nodes = document.querySelectorAll(".reveal");
  if (!nodes.length) return;
  if (prefersReducedMotion() || !("IntersectionObserver" in window)) {
    nodes.forEach(function (el) { el.classList.add("is-in"); });
    return;
  }
  var io = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("is-in");
      io.unobserve(entry.target);
    });
  }, { rootMargin: "0px 0px -8% 0px", threshold: 0.12 });
  nodes.forEach(function (el) { io.observe(el); });
}

var currentLang = "sv";

document.addEventListener("DOMContentLoaded", function () {
  currentLang = detectLang();
  document.querySelectorAll(".lang button").forEach(function (btn) {
    btn.addEventListener("click", function () {
      setLang(btn.getAttribute("data-lang"), { animate: true });
    });
  });
  setupMenu();
  setupSectionWatch();
  setupMedia();
  setupPressDownloads();
  setupToTop();
  setupReveal();
  setLang(currentLang);
});
